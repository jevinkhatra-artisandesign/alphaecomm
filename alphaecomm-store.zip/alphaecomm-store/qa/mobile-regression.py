"""
Mobile regression QA for the Alphaecomm storefront.
Runs against a production server on :3100. Usage: python3 qa_mobile.py [label]
"""
import json, re, sys, urllib.parse
from collections import defaultdict
from playwright.sync_api import sync_playwright

BASE = "http://localhost:3100"
AXE = open("/tmp/package/axe.min.js").read()
LABEL = sys.argv[1] if len(sys.argv) > 1 else "run"

DEVICES = [
    ("Small Android 320", 320, 640),
    ("Android 360", 360, 780),
    ("iPhone 390", 390, 844),
    ("Large phone 430", 430, 932),
    ("Tablet 768", 768, 1024),
    ("Phone landscape 844x390", 844, 390),
]
PAGES = ["/", "/shop", "/category/kitchen-dining", "/category/home-living", "/category/toys-kids",
         "/category/everyday-essentials", "/product/dry-fruit-slicer", "/product/stainless-steel-lunch-box-pink",
         "/product/projector-flashlight-toy", "/product/racing-car-toy-red", "/product/racing-car-toy-black-orange",
         "/product/baby-spinner-toy-set-of-3", "/product/beach-sand-bucket-set", "/product/not-real"]

issues = defaultdict(set)      # category -> set of descriptions
checks = []                    # (name, passed)

def check(name, ok, detail=""):
    checks.append((name, bool(ok)))
    if not ok:
        issues["Functional"].add(f"{name} — {detail}")

LAYOUT_JS = """() => {
  const vw = document.documentElement.clientWidth;
  const out = { overflow: document.documentElement.scrollWidth - vw, offscreen: [], smallTargets: [], tinyText: [], iosZoom: [], clipped: [] };
  const visible = el => { const r = el.getBoundingClientRect(); const s = getComputedStyle(el);
    return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && el.offsetParent !== null; };
  const inScroller = el => { for (let p = el.parentElement; p; p = p.parentElement) {
    const o = getComputedStyle(p).overflowX; if (o === 'auto' || o === 'scroll') return true; } return false; };
  const label = el => (el.getAttribute('aria-label') || el.innerText || el.placeholder || el.tagName).trim().replace(/\\s+/g,' ').slice(0,40);
  // 1. elements poking outside the viewport (excluding intentional horizontal scrollers)
  document.querySelectorAll('body *').forEach(el => {
    if (!visible(el) || inScroller(el)) return;
    const r = el.getBoundingClientRect();
    if (r.right > vw + 1 || r.left < -1) out.offscreen.push(el.tagName + ' ' + label(el));
  });
  // 2. touch targets (WCAG 2.2 AA 2.5.8: 24px, or 24px spacing) + recommended 44px
  const targets = [...document.querySelectorAll('a[href], button, input, select, [role=button]')].filter(visible);
  const rects = targets.map(t => t.getBoundingClientRect());
  targets.forEach((t, i) => {
    const r = rects[i];
    const inline = t.tagName === 'A' && getComputedStyle(t).display === 'inline' && t.closest('p');
    if (inline) return; // inline links in sentences are exempt
    if (r.width < 24 || r.height < 24) {
      // spacing exception: a 24px circle centred on the target must not overlap other targets
      const cx = r.left + r.width/2, cy = r.top + r.height/2;
      const crowded = rects.some((o, j) => j !== i && Math.hypot(Math.max(o.left - cx, 0, cx - o.right), Math.max(o.top - cy, 0, cy - o.bottom)) < 12);
      if (crowded) out.smallTargets.push(`FAIL ${label(t)} ${Math.round(r.width)}x${Math.round(r.height)}`);
      else out.smallTargets.push(`small-ok-spacing ${label(t)} ${Math.round(r.width)}x${Math.round(r.height)}`);
    } else if (r.height < 44 && ['BUTTON','INPUT','SELECT'].includes(t.tagName)) {
      out.smallTargets.push(`below44 ${t.tagName} ${label(t)} ${Math.round(r.width)}x${Math.round(r.height)}`);
    }
  });
  // 3. text smaller than 12px
  document.querySelectorAll('body *').forEach(el => {
    if (!visible(el)) return;
    const own = [...el.childNodes].some(n => n.nodeType === 3 && n.textContent.trim());
    const fs = parseFloat(getComputedStyle(el).fontSize);
    if (own && fs < 12) out.tinyText.push(`${fs}px "${el.textContent.trim().slice(0,30)}"`);
  });
  // 4. iOS Safari zooms the page when a focused field's text is under 16px
  document.querySelectorAll('input, select, textarea').forEach(el => {
    if (!visible(el)) return;
    const fs = parseFloat(getComputedStyle(el).fontSize);
    if (fs < 16) out.iosZoom.push(`${el.tagName.toLowerCase()} "${label(el)}" ${fs}px`);
  });
  // 5. text clipped by its own box
  document.querySelectorAll('h1,h2,h3,p,a,button,span').forEach(el => {
    if (!visible(el)) return;
    const s = getComputedStyle(el);
    const srOnly = el.getBoundingClientRect().width <= 1 || s.clip === 'rect(0px, 0px, 0px, 0px)' || s.clipPath === 'inset(50%)';
    if (!srOnly && (s.overflow === 'hidden' || s.textOverflow === 'ellipsis') && el.scrollWidth > el.clientWidth + 1)
      out.clipped.push(label(el));
  });
  return out;
}"""

with sync_playwright() as p:
    browser = p.chromium.launch()
    errors = []

    # ---------- A. Layout, targets, text, iOS zoom on every page × device ----------
    for name, w, h in DEVICES:
        ctx = browser.new_context(viewport={"width": w, "height": h}, device_scale_factor=2,
                                  is_mobile=w < 700 or h < 500, has_touch=True)
        pg = ctx.new_page()
        pg.on("pageerror", lambda e: errors.append(str(e)))
        pg.on("console", lambda m: errors.append(m.text) if m.type == "error" and "not-real" not in pg.url else None)
        for path in PAGES:
            pg.goto(BASE + path, wait_until="networkidle")
            r = pg.evaluate(LAYOUT_JS)
            where = f"{name} {path}"
            if r["overflow"] > 0: issues["Horizontal overflow"].add(f"{where}: page {r['overflow']}px wider than screen")
            for o in r["offscreen"][:3]: issues["Element outside screen"].add(f"{where}: {o}")
            for t in r["smallTargets"]:
                key = "Touch target FAIL (<24px, crowded)" if t.startswith("FAIL") else ("Touch target below 44px (advisory)" if t.startswith("below44") else None)
                if key: issues[key].add(f"{name}: {t.split(' ',1)[1]}")
            for t in r["tinyText"]: issues["Text under 12px"].add(f"{name}: {t}")
            for z in r["iosZoom"]: issues["iOS zoom-on-focus (field text < 16px)"].add(f"{z}")
            for c in r["clipped"]: issues["Clipped text"].add(f"{where}: {c}")
        if w < 768:
            pg.goto(BASE + "/shop", wait_until="networkidle")
            pg.tap("button[aria-label='Open menu']")
            r = pg.evaluate(LAYOUT_JS)
            if r["overflow"] > 0: issues["Horizontal overflow"].add(f"{name} menu open: {r['overflow']}px")
            for z in r["iosZoom"]: issues["iOS zoom-on-focus (field text < 16px)"].add(f"menu open: {z}")
            for t in r["smallTargets"]:
                if t.startswith("FAIL"): issues["Touch target FAIL (<24px, crowded)"].add(f"{name} menu: {t}")
        ctx.close()

    # ---------- B. Accessibility audit (axe-core, WCAG 2.2 AA) at phone size ----------
    ctx = browser.new_context(viewport={"width": 390, "height": 844}, is_mobile=True, has_touch=True)
    pg = ctx.new_page()
    for path in PAGES:
        pg.goto(BASE + path, wait_until="networkidle")
        pg.add_script_tag(content=AXE)
        res = pg.evaluate("""async () => (await axe.run(document, {runOnly: {type:'tag', values:['wcag2a','wcag2aa','wcag21a','wcag21aa','wcag22aa','best-practice']}})).violations
            .map(v => ({id: v.id, impact: v.impact, help: v.help, nodes: v.nodes.slice(0,3).map(n => n.target.join(' '))}))""")
        for v in res:
            issues[f"Accessibility ({v['impact']})"].add(f"{v['id']}: {v['help']} — e.g. {v['nodes'][0][:70]}")
    # mobile menu open state audited too
    pg.goto(BASE + "/shop", wait_until="networkidle")
    pg.tap("button[aria-label='Open menu']")
    pg.add_script_tag(content=AXE)
    for v in pg.evaluate("async () => (await axe.run()).violations.map(v => v.id + ': ' + v.help)"):
        issues["Accessibility (menu open)"].add(v)
    ctx.close()

    # ---------- C. Touch-driven flows on a phone ----------
    ctx = browser.new_context(viewport={"width": 390, "height": 844}, device_scale_factor=3, is_mobile=True, has_touch=True)
    pg = ctx.new_page()
    pg.on("pageerror", lambda e: errors.append(str(e)))
    vis_names = lambda: pg.locator("main ul.grid > li article h3").filter(visible=True).all_inner_texts()

    pg.goto(BASE + "/", wait_until="networkidle")
    menu = pg.locator("button[aria-label='Open menu']")
    check("Menu button visible on phone", menu.is_visible())
    menu.tap()
    check("Menu opens on tap", pg.get_by_role("button", name="Close menu").is_visible())
    box = pg.evaluate("(() => { const p = document.querySelector('header [id] nav').parentElement.getBoundingClientRect(); return [p.bottom, innerHeight]; })()")
    check("Open menu fits on screen", box[0] <= box[1], box)
    pg.keyboard.press("Escape")
    check("Escape closes menu", pg.get_by_role("button", name="Open menu").is_visible())
    pg.get_by_role("button", name="Open menu").tap()
    pg.locator("header nav a", has_text="Shop").filter(visible=True).tap()
    pg.wait_for_url("**/shop")
    check("Menu link navigates and closes menu", pg.get_by_role("button", name="Open menu").filter(visible=True).count() == 1)

    pg.mouse.wheel(0, 1500); pg.wait_for_timeout(300)
    top = pg.evaluate("document.querySelector('header').getBoundingClientRect().top")
    check("Header stays pinned while scrolling", abs(top) < 1, top)
    pg.evaluate("scrollTo(0,0)")

    chips = pg.locator("[aria-label='Filter by category'] button").filter(visible=True)
    check("Category chips visible on phone", chips.count() == 5, chips.count())
    sc = pg.evaluate("(() => { const s = document.querySelector('[aria-label=\"Filter by category\"]'); return [s.scrollWidth, s.clientWidth]; })()")
    check("Chip row scrolls sideways instead of overflowing", sc[0] > sc[1], sc)
    chips.nth(4).scroll_into_view_if_needed(); chips.nth(4).tap()
    check("Tapping last chip filters (Everyday Essentials)", vis_names() == ["Stainless Steel Lunch Box – Pink"], vis_names())
    chips.nth(0).scroll_into_view_if_needed(); chips.nth(0).tap()
    search = pg.locator("main").get_by_role("searchbox").filter(visible=True)
    search.tap(); search.type("slicer")
    check("Typing on phone filters live", vis_names() == ["Dry Fruit Slicer"], vis_names())
    search.fill("")
    search.type("stainless steel lunch", delay=0)
    pg.wait_for_timeout(400)
    check("Very fast typing keeps every letter", search.input_value() == "stainless steel lunch", search.input_value())
    for _ in range(6): search.press("Backspace", delay=0)
    pg.wait_for_timeout(400)
    check("Fast deleting keeps text in sync", search.input_value() == "stainless steel" and set(vis_names()) == {"Dry Fruit Slicer", "Stainless Steel Lunch Box – Pink"}, (search.input_value(), vis_names()))
    search.fill("slicer")
    pg.get_by_role("button", name="Clear search").tap()
    check("Clear button works by tap", len(vis_names()) == 7)
    pg.get_by_label("Sort by").filter(visible=True).select_option("name-asc")
    n = vis_names()
    check("Sort on phone", n == sorted(n) and len(n) == 7, n)
    cols = pg.evaluate("getComputedStyle(document.querySelector('main ul.grid')).gridTemplateColumns.split(' ').length")
    check("Two product columns on phone", cols == 2, cols)
    heights = pg.evaluate("[...document.querySelectorAll('main ul.grid > li')].filter(l=>l.offsetParent).map(l => Math.round(l.getBoundingClientRect().height))")
    rows = [heights[i:i+2] for i in range(0, len(heights), 2)]
    check("Cards in a row have equal height", all(len(set(r)) == 1 for r in rows), rows)

    pg.locator("main ul.grid a[href='/product/dry-fruit-slicer']").first.tap()
    pg.wait_for_url("**/product/dry-fruit-slicer")
    thumbs = pg.locator("button[aria-label^='Show image']").filter(visible=True)
    thumbs.nth(1).tap()
    check("Gallery thumbnail tap", "dry-fruit-slicer%2F02" in pg.locator("main img").filter(visible=True).first.get_attribute("src"))
    order = pg.get_by_role("link", name=re.compile("^Order .* on WhatsApp")).filter(visible=True)
    ob = order.bounding_box()
    check("Order button full width on phone", ob["width"] >= 390 - 2 * 20 - 2, ob)
    msg = urllib.parse.unquote(order.get_attribute("href").split("text=")[1])
    check("Order message complete", all(s in msg for s in ["AE-KD-001", "Price: ₹154", "product/dry-fruit-slicer", "shipping charges"]), msg)
    pg.go_back(); pg.wait_for_url("**/shop*")
    check("Back button returns to shop", vis_names() != [])

    land = browser.new_context(viewport={"width": 844, "height": 390}, is_mobile=True, has_touch=True).new_page()
    land.goto(BASE + "/", wait_until="networkidle")
    hh = land.evaluate("document.querySelector('header').getBoundingClientRect().height")
    check("Landscape: header ≤ 20% of screen height", hh <= 390 * 0.2, hh)
    ctx.close()

    if errors:
        issues["Browser errors"].update(errors)
    browser.close()

passed = sum(ok for _, ok in checks)
print(f"\n=== {LABEL}: functional flows {passed}/{len(checks)} passed ===")
for cat in sorted(issues):
    items = sorted(issues[cat])
    print(f"\n[{cat}] {len(items)}")
    for i in items[:12]:
        print("  -", i)
    if len(items) > 12:
        print(f"  … +{len(items) - 12} more")
json.dump({k: sorted(v) for k, v in issues.items()}, open(f"/home/claude/qa-{LABEL}.json", "w"), indent=1)
