"""WhatsApp integration checks: every link, the floating button, and its placement."""
import re, urllib.parse
from playwright.sync_api import sync_playwright
BASE = "http://localhost:3100"; NUMBER = "919265113493"
PAGES = ["/", "/shop", "/category/kitchen-dining", "/category/home-living", "/category/toys-kids",
         "/category/everyday-essentials", "/product/dry-fruit-slicer", "/product/stainless-steel-lunch-box-pink",
         "/product/projector-flashlight-toy", "/product/racing-car-toy-red", "/product/racing-car-toy-black-orange",
         "/product/baby-spinner-toy-set-of-3", "/product/beach-sand-bucket-set"]
ok = []
def check(n, c, d=""): ok.append(bool(c)); print(("PASS " if c else "FAIL ") + n + ("" if c else f"  [{d}]"))
with sync_playwright() as p:
    b = p.chromium.launch()
    for label, w, h in [("phone", 390, 844), ("desktop", 1440, 900)]:
        pg = b.new_page(viewport={"width": w, "height": h}, is_mobile=w < 700, has_touch=w < 700)
        total = 0; wrong = []; disabled = 0; missing_float = []
        for path in PAGES:
            pg.goto(BASE + path, wait_until="networkidle")
            links = pg.locator("a[href*='wa.me']")
            for i in range(links.count()):
                href = links.nth(i).get_attribute("href"); total += 1
                if not href.startswith(f"https://wa.me/{NUMBER}?text=") or links.nth(i).get_attribute("target") != "_blank" or "noopener" not in (links.nth(i).get_attribute("rel") or ""):
                    wrong.append(href[:40])
            disabled += pg.locator("button[disabled][title*='WhatsApp']").count()
            if pg.get_by_role("link", name="Chat with us on WhatsApp (opens WhatsApp)").filter(has=pg.locator("svg")).locator("visible=true").count() == 0:
                fl = pg.locator("a.fixed[href*='wa.me']")
                if fl.count() != 1 or not fl.is_visible(): missing_float.append(path)
        check(f"{label}: all {total} WhatsApp links go to wa.me/{NUMBER}, open safely in a new tab", not wrong, wrong[:3])
        check(f"{label}: no disabled WhatsApp buttons remain", disabled == 0, disabled)
        check(f"{label}: floating button on all {len(PAGES)} pages", not missing_float, missing_float)

        pg.goto(BASE + "/", wait_until="networkidle")
        fl = pg.locator("a.fixed[href*='wa.me']"); bb = fl.bounding_box()
        check(f"{label}: floating button ≥44px tall", bb["height"] >= 44, bb)
        check(f"{label}: floating button inside the screen", bb["x"] + bb["width"] <= w and bb["y"] + bb["height"] <= h, bb)
        msg = urllib.parse.unquote(fl.get_attribute("href").split("text=")[1])
        check(f"{label}: floating message is a general enquiry", msg.startswith("Hello Alphaecomm Enterprise"), msg)
        pg.mouse.wheel(0, 3000); pg.wait_for_timeout(300)
        check(f"{label}: floating button stays visible after scrolling", fl.is_visible() and abs(fl.bounding_box()["y"] - bb["y"]) < 2)
        # At the very bottom, the footer's last line must not sit under the button
        pg.evaluate("scrollTo(0, document.body.scrollHeight)"); pg.wait_for_timeout(300)
        last = pg.locator("footer p").last.bounding_box(); fb = fl.bounding_box()
        overlap = not (last["x"] + last["width"] < fb["x"] or last["y"] > fb["y"] + fb["height"] or last["y"] + last["height"] < fb["y"])
        check(f"{label}: footer's last line not covered at page bottom", not overlap, (last, fb))
        if label == "phone":
            check("phone: floating button is an icon (label hidden visually, kept for screen readers)", bb["width"] <= 60, bb)
        pg.screenshot(path=f"/home/claude/wa-{label}.png")
        pg.close()

    # Product page: the main order button must stay tappable, not hidden under the floating one
    pg = b.new_page(viewport={"width": 390, "height": 844}, is_mobile=True, has_touch=True)
    pg.goto(BASE + "/product/dry-fruit-slicer", wait_until="networkidle")
    order = pg.get_by_role("link", name=re.compile("^Order .* on WhatsApp")); order.scroll_into_view_if_needed()
    ob = order.bounding_box()
    hit = pg.evaluate("([x,y]) => document.elementFromPoint(x,y).closest('a')?.getAttribute('aria-label')", [ob["x"] + ob["width"] / 2, ob["y"] + ob["height"] / 2])
    check("phone: product 'Order on WhatsApp' button is tappable (centre not covered)", hit and hit.startswith("Order"), hit)
    msg = urllib.parse.unquote(order.get_attribute("href").split("text=")[1])
    check("phone: product order message has price, SKU and link", all(s in msg for s in ["Price: ₹154", "SKU: AE-KD-001", "product/dry-fruit-slicer"]), msg)
    b.close()
print(f"\n{sum(ok)}/{len(ok)} checks passed")
