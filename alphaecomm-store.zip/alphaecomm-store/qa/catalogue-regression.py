"""Catalogue regression against the real product data (desktop + phone). Server on :3100."""
import re, urllib.parse
from playwright.sync_api import sync_playwright, expect
BASE = "http://localhost:3100"
results = []
def check(name, cond, detail=""):
    results.append(bool(cond)); print(("PASS " if cond else "FAIL ") + name + ("" if cond else f"  [{detail}]"))

ALL = ["Dry Fruit Slicer", "Stainless Steel Lunch Box – Pink", "Projector Flashlight Toy",
       "Formula-Style Racing Car Toy – Red", "Formula-Style Racing Car Toy – Black & Orange",
       "Baby Spinner Toy – Set of 3", "Beach Sand Bucket Set"]
TOYS = {"Projector Flashlight Toy", "Formula-Style Racing Car Toy – Red", "Formula-Style Racing Car Toy – Black & Orange",
        "Baby Spinner Toy – Set of 3", "Beach Sand Bucket Set"}

def names(pg):
    pg.wait_for_timeout(150)
    return pg.locator("main ul li article h3").filter(visible=True).all_inner_texts()

with sync_playwright() as p:
    b = p.chromium.launch(); errors = []
    pg = b.new_page(viewport={"width": 1440, "height": 900})
    pg.on("pageerror", lambda e: errors.append(str(e)))

    # Homepage
    pg.goto(BASE + "/", wait_until="networkidle")
    check("Home: 4 featured products", names(pg)[:4] == ALL[:4], names(pg)[:4])
    tile = pg.locator("#categories a[href='/category/home-living']")
    check("Home: empty category says 'Coming soon'", "Coming soon" in tile.inner_text())
    check("Home: Toys tile counts 5", "5 products" in pg.locator("#categories a[href='/category/toys-kids']").inner_text())
    check("No 'Sample' badges remain", pg.get_by_text("Sample", exact=True).count() == 0)

    # Shop
    pg.goto(BASE + "/shop", wait_until="networkidle")
    check("Shop lists all 7, featured first", names(pg) == ALL, names(pg))
    check("Shop HTML contains products (SEO)", "Dry Fruit Slicer" in pg.content())
    check("Only the unpriced spinner shows 'Price on request'", pg.get_by_text("Price on request").filter(visible=True).count() == 1)
    check("Prices shown in rupees", all(t in pg.locator("main").inner_text() for t in ["₹154", "₹401", "₹204", "₹269", "₹289", "₹247"]))
    check("Genuine MRP struck through with % off", all(t in pg.locator("main").inner_text() for t in ["₹238", "14% off", "₹290", "15% off"]))
    s = pg.locator("main").get_by_role("searchbox").filter(visible=True)
    s.fill("lunch"); check("Search by name", names(pg) == ["Stainless Steel Lunch Box – Pink"], names(pg))
    s.fill("AE-TK-004"); check("Search by SKU", names(pg) == ["Baby Spinner Toy – Set of 3"], names(pg))
    s.fill("tk-00"); check("Partial SKU finds all toys", set(names(pg)) == TOYS, names(pg))
    s.fill("racing"); check("Keyword finds both cars", set(names(pg)) == {ALL[3], ALL[4]}, names(pg))
    s.fill("almonds"); check("Tag search", names(pg) == ["Dry Fruit Slicer"], names(pg))
    s.fill("xyzzy"); pg.wait_for_timeout(100)
    check("Empty state", pg.get_by_text("No products match").is_visible())
    pg.get_by_role("button", name="Clear filters").click(); check("Clear filters", len(names(pg)) == 7)
    aside = pg.locator("aside")
    counts = aside.locator("button span.tabular-nums").all_inner_texts()
    check("Category counts from data (7,1,0,5,1)", counts == ["7", "1", "0", "5", "1"], counts)
    aside.get_by_role("button", name=re.compile("Toys & Kids")).click()
    check("Category filter", set(names(pg)) == TOYS, names(pg))
    pg.get_by_label("Sort by").filter(visible=True).select_option("name-asc"); n = names(pg)
    check("Filter + sort A→Z", n == sorted(n) and len(n) == 5, n)
    s.fill("car"); n = names(pg)
    check("Search + filter + sort together", n == [ALL[4], ALL[3]] or n == sorted(n), n)
    check("All state kept in URL", all(k in pg.url for k in ["q=car", "category=toys-kids", "sort=name-asc"]), pg.url)
    pg.get_by_label("Sort by").filter(visible=True).select_option("price-asc"); n2 = names(pg)
    check("Price sort within filter", n2 == [ALL[6], ALL[3], ALL[4]], n2)
    pg.goto(BASE + "/shop?sort=price-asc", wait_until="networkidle"); n3 = names(pg)
    check("Price low→high, unpriced last", n3 == [ALL[0], ALL[2], ALL[6], ALL[3], ALL[4], ALL[1], ALL[5]], n3)
    pg.goto(BASE + "/shop?sort=price-desc", wait_until="networkidle"); n4 = names(pg)
    check("Price high→low, unpriced last", n4 == [ALL[1], ALL[4], ALL[3], ALL[6], ALL[2], ALL[0], ALL[5]], n4)

    pg.goto(BASE + "/shop?q=spinner", wait_until="networkidle")
    check("Shared URL restores search", names(pg) == ["Baby Spinner Toy – Set of 3"], names(pg))

    # Category pages
    pg.goto(BASE + "/category/kitchen-dining", wait_until="networkidle")
    check("Kitchen page lists the slicer", names(pg) == ["Dry Fruit Slicer"], names(pg))
    pg.goto(BASE + "/category/home-living", wait_until="networkidle")
    check("Empty category shows coming-soon", pg.get_by_text("New products coming soon").is_visible())
    check("Empty category hides search/sort", pg.locator("main").get_by_role("searchbox").filter(visible=True).count() == 0)

    # Product page
    pg.goto(BASE + "/product/racing-car-toy-black-orange", wait_until="networkidle")
    th = pg.locator("button[aria-label^='Show image']").filter(visible=True)
    check("Gallery has 6 thumbnails", th.count() == 6, th.count())
    th.nth(2).click(); pg.wait_for_timeout(300)
    src = urllib.parse.unquote(pg.locator("main img").filter(visible=True).first.get_attribute("src"))
    check("Thumbnail swaps main image", "racing-car-toy-black-orange/03.webp" in src, src)
    check("Specs shown (age from box)", pg.get_by_text("Age (printed on box)").is_visible())
    check("Product title has no 'F1'/'Formula 1'", not re.search(r"\bF1\b|Formula 1", pg.title() + pg.locator("h1").inner_text()), pg.title())
    order = pg.get_by_role("link", name=re.compile("^Order .* on WhatsApp")).filter(visible=True)
    msg = urllib.parse.unquote(order.get_attribute("href").split("text=")[1])
    for part in ["Alphaecomm Enterprise", "Formula-Style Racing Car Toy – Black & Orange", "SKU: AE-TK-003",
                 "https://shop.example.test/product/racing-car-toy-black-orange", "Price: ₹289", "confirm availability and shipping charges"]:
        check(f"Order message has '{part[:40]}'", part in msg, msg)
    check("Page description includes price", "₹289" in (pg.locator("meta[name=description]").get_attribute("content") or ""))
    pg.goto(BASE + "/product/baby-spinner-toy-set-of-3", wait_until="networkidle")
    o2 = pg.get_by_role("link", name=re.compile("^Order .* on WhatsApp")).filter(visible=True)
    m2 = urllib.parse.unquote(o2.get_attribute("href").split("text=")[1])
    check("Unpriced product message asks for price", "Price:" not in m2 and "share the price" in m2, m2)

    pg.goto(BASE + "/product/dry-fruit-slicer", wait_until="networkidle")
    rel = pg.locator("section[aria-labelledby=related-dry-fruit-slicer] article h3").all_inner_texts()
    check("Related: in-stock featured fill (no same-category items)", rel == [ALL[1], ALL[2], ALL[3]], rel)
    imgs = pg.evaluate("[...document.querySelectorAll('main img')].filter(i=>i.offsetParent).map(i=>i.currentSrc)")
    check("Images served optimised (WebP via Next.js)", all("_next/image" in u or u.endswith(".svg") for u in imgs), imgs[:2])

    for path in ["/product/nope", "/category/nope"]:
        r = pg.goto(BASE + path); check(f"404 for {path}", r.status == 404, r.status)

    for w, h in [(390, 844), (820, 1180)]:
        q = b.new_page(viewport={"width": w, "height": h})
        for path in ["/", "/shop", "/category/toys-kids", "/category/home-living", "/product/racing-car-toy-black-orange"]:
            q.goto(BASE + path, wait_until="networkidle")
            check(f"No overflow {w}px {path}", q.evaluate("document.documentElement.scrollWidth") <= w)
        q.close()
    check("No JS errors", not errors, errors)
    b.close()
print(f"\n{sum(results)}/{len(results)} checks passed")
