# QA scripts

Browser regression tests (Python + Playwright) used during development.

- `catalogue-regression.py`: 55 checks against the real catalogue: search, filters, sorting, gallery, WhatsApp messages, 404s and layouts.
- `logic-check.ts`: price sorting and WhatsApp message rules (`npx tsx qa/logic-check.ts`).
- `mobile-regression.py`: 6 device sizes × 15 pages: overflow, touch targets, text size, iOS zoom, axe-core accessibility audit, and touch-driven flows.

Run against a production build on port 3100:

```bash
npm run build && npx next start -p 3100
pip install playwright && playwright install chromium
python3 qa/catalogue-regression.py
python3 qa/mobile-regression.py   # needs axe-core at /tmp/package/axe.min.js (npm pack axe-core)
```
- `hero-overlap.py`: checks every line of hero text against where each product renders in the banner, at 8 desktop widths. Rerun it if you change the banner image or hero text.
- `whatsapp-check.py`: every WhatsApp link on every page uses the configured number; the floating button is visible, tappable and never covers the footer or the order button.
