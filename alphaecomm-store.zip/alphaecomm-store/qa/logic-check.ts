/**
 * Code-level checks for rules the current catalogue can't exercise in a browser
 * (no out-of-stock or priced products yet). Run: npx tsx qa/logic-check.ts
 */
import { sortProducts, applyCatalogueState, DEFAULT_CATALOGUE_STATE } from "@/lib/catalogue";
import { getProductOrderMessage, getUnavailableProductMessage } from "@/lib/whatsapp";
import type { Product } from "@/types/product";

let failed = 0;
function check(name: string, ok: boolean, detail?: unknown): void {
  console.log(`${ok ? "PASS" : "FAIL"} ${name}${ok ? "" : ` — ${JSON.stringify(detail)}`}`);
  if (!ok) failed++;
}

const base = { shortDescription: "", description: "", images: [], inStock: true, featured: false, tags: [], categorySlug: "toys-kids" };
const p = (name: string, price?: number): Product => ({ ...base, id: name, slug: name, sku: name, name, price });
const list = [p("A", 500), p("B"), p("C", 100), p("D"), p("E", 300)];

const asc = sortProducts(list, "price-asc").map((x) => x.name);
check("Low→high puts unpriced last", asc.join() === "C,E,A,B,D", asc);
const desc = sortProducts(list, "price-desc").map((x) => x.name);
check("High→low puts unpriced last", desc.join() === "A,E,C,B,D", desc);
const az = applyCatalogueState(list, { ...DEFAULT_CATALOGUE_STATE, sort: "name-asc" }, []).map((x) => x.name);
check("Name A→Z", az.join() === "A,B,C,D,E", az);

const details = { name: "Toy", sku: "AE-X", url: "https://x/product/toy" };
const priced = getProductOrderMessage({ ...details, displayPrice: "₹299" });
check("Priced order message includes price", priced.includes("Price: ₹299") && priced.includes("confirm availability and shipping charges"), priced);
const unpriced = getProductOrderMessage(details);
check("Unpriced order message asks for price", !unpriced.includes("Price:") && unpriced.includes("share the price"), unpriced);
const oos = getUnavailableProductMessage(details);
check("Out-of-stock message says unavailable", oos.includes("out of stock") && oos.includes("AE-X"), oos);

if (failed) process.exit(1);
console.log("All logic checks passed");
