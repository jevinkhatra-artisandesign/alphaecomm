"""Checks every line of hero text against where each product actually renders in the banner."""
import sys
from playwright.sync_api import sync_playwright
JS = """() => {
  const sec = document.querySelector('section[aria-labelledby=hero-title]');
  const img = sec.querySelector('img'); const r = img.getBoundingClientRect();
  const nw = img.naturalWidth, nh = img.naturalHeight; let w = r.width, h = r.height, x = r.left, y = r.top;
  if (getComputedStyle(img).objectFit === 'cover') { const s = Math.max(r.width/nw, r.height/nh); w = nw*s; h = nh*s; x = r.right - w; y = r.bottom - h; }
  const box = (l,t,rr,b) => ({ l: x+l*w, t: y+t*h, r: x+rr*w, b: y+b*h });
  // product footprints in the wide banner, measured from the image (fractions of width/height)
  const products = { 'racing car': box(0.305,0.65,0.545,0.86), 'slicer': box(0.505,0.25,0.715,0.60),
    'spinner': box(0.565,0.65,0.675,0.85), 'lunch box': box(0.73,0.28,0.92,0.55) };
  // every text line: use Range rects so we test real glyph lines, not empty block space
  const lines = [];
  sec.querySelectorAll('h1, p, a').forEach(el => { const rg = document.createRange(); rg.selectNodeContents(el);
    [...rg.getClientRects()].forEach(q => q.width > 2 && lines.push({ what: el.tagName, l: q.left, t: q.top, r: q.right, b: q.bottom })); });
  const hits = [];
  for (const [name, p] of Object.entries(products)) for (const L of lines)
    if (L.r > p.l + 4 && L.l < p.r - 4 && L.b > p.t + 4 && L.t < p.b - 4) hits.push(`${L.what} over ${name}`);
  return { hits: [...new Set(hits)], heroH: Math.round(sec.getBoundingClientRect().height) };
}"""
widths = [(1280,800),(1366,768),(1440,900),(1536,900),(1600,900),(1680,1000),(1920,1080),(2560,1300)]
bad = 0
with sync_playwright() as p:
    b = p.chromium.launch()
    for w, h in widths:
        pg = b.new_page(viewport={"width": w, "height": h})
        pg.goto("http://localhost:3100/", wait_until="networkidle"); pg.wait_for_timeout(300)
        r = pg.evaluate(JS); bad += bool(r["hits"])
        print(f"{w}px  hero {r['heroH']}px  ", "CLEAR" if not r["hits"] else "OVERLAP: " + ", ".join(r["hits"]))
        if len(sys.argv) > 1: pg.screenshot(path=f"/home/claude/h-d{w}.png", clip={"x":0,"y":0,"width":w,"height":r['heroH']+70})
        pg.close()
    b.close()
print("ALL CLEAR" if not bad else f"{bad} widths with overlap")
