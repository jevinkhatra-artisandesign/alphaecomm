const rupeeFormatter = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  maximumFractionDigits: 0,
});

/** Formats a whole-rupee amount, e.g. 1499 → "₹1,499". */
export function formatPrice(amount: number): string {
  return rupeeFormatter.format(amount);
}
