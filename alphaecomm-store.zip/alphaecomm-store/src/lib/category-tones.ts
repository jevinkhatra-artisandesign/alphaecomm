/**
 * Colour tone for each category. Class names are written out in full so
 * Tailwind can find them. Add a line here when you add a category;
 * unknown categories fall back to the neutral tone.
 */
export interface CategoryTone {
  /** Soft background for cards and header bands. */
  surface: string;
  /** Small solid dot used in filters. */
  dot: string;
}

const tones: Record<string, CategoryTone> = {
  "kitchen-dining": { surface: "bg-tone-sage", dot: "bg-dot-sage" },
  "home-living": { surface: "bg-tone-sand", dot: "bg-dot-sand" },
  "toys-kids": { surface: "bg-tone-sky", dot: "bg-dot-sky" },
  "everyday-essentials": { surface: "bg-tone-butter", dot: "bg-dot-butter" },
};

const neutral: CategoryTone = { surface: "bg-stone", dot: "bg-slate" };

export function getCategoryTone(slug: string): CategoryTone {
  return tones[slug] ?? neutral;
}
