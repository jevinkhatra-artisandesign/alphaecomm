/** Site-wide configuration shared by layout, metadata and navigation. */

export const siteConfig = {
  name: "Alphaecomm Enterprise",
  shortName: "Alphaecomm",
  description:
    "Kitchenware, home organisation, toys and everyday essentials. Browse the catalogue and order directly on WhatsApp.",
} as const;

export interface NavItem {
  label: string;
  href: string;
}

/** Categories and About scroll to homepage sections. */
export const mainNav: NavItem[] = [
  { label: "Home", href: "/" },
  { label: "Shop", href: "/shop" },
  { label: "Categories", href: "/#categories" },
  { label: "About", href: "/#about" },
];

export const policyNav: NavItem[] = [
  { label: "Shipping policy", href: "/policies/shipping" },
  { label: "Returns & refunds", href: "/policies/returns" },
  { label: "Privacy policy", href: "/policies/privacy" },
  { label: "Terms of service", href: "/policies/terms" },
];

function parseConfiguredSiteUrl(): URL | null {
  const raw = process.env.NEXT_PUBLIC_SITE_URL?.trim();
  if (!raw) return null;
  try {
    return new URL(raw);
  } catch {
    return null;
  }
}

/** True when NEXT_PUBLIC_SITE_URL holds a valid URL. Canonical tags depend on this. */
export function isSiteUrlConfigured(): boolean {
  return parseConfiguredSiteUrl() !== null;
}

/** Absolute site URL used for metadata and shared links. Falls back to localhost in development. */
export function getSiteUrl(): URL {
  return parseConfiguredSiteUrl() ?? new URL("http://localhost:3000");
}

/** Turns a path like "/product/x" into a full URL on the site. */
export function getAbsoluteUrl(path: string): string {
  return new URL(path, getSiteUrl()).toString();
}

/** Canonical link metadata, only when the public site URL is configured. */
export function getCanonical(path: string): { canonical: string } | undefined {
  return isSiteUrlConfigured() ? { canonical: path } : undefined;
}
