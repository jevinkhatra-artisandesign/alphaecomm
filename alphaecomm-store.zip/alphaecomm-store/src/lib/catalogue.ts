/**
 * Search, filter and sort logic for product listings.
 * Pure functions with no React — used by the shop page and category pages.
 */
import type { Category, Product } from "@/types/product";

export const SORT_OPTIONS = [
  { value: "featured", label: "Featured" },
  { value: "price-asc", label: "Price: Low to High" },
  { value: "price-desc", label: "Price: High to Low" },
  { value: "name-asc", label: "Name: A to Z" },
] as const;

export type SortOption = (typeof SORT_OPTIONS)[number]["value"];

export interface CatalogueState {
  query: string;
  /** Category slug, or null for all products. */
  category: string | null;
  sort: SortOption;
}

export const DEFAULT_CATALOGUE_STATE: CatalogueState = {
  query: "",
  category: null,
  sort: "featured",
};

function isSortOption(value: string | null): value is SortOption {
  return SORT_OPTIONS.some((option) => option.value === value);
}

function normalise(text: string): string {
  return text.toLowerCase().normalize("NFKD").replace(/\s+/g, " ").trim();
}

/** Splits a search into words; every word must appear somewhere in the product. */
export function searchTerms(query: string): string[] {
  return normalise(query).split(" ").filter(Boolean);
}

export function matchesSearch(product: Product, terms: string[], categoryName = ""): boolean {
  if (terms.length === 0) return true;
  const haystack = normalise(
    [
      product.name,
      product.sku,
      product.shortDescription,
      product.description,
      categoryName,
      ...product.tags,
    ].join(" "),
  );
  return terms.every((term) => haystack.includes(term));
}

function categoryNames(categories: Category[]): Map<string, string> {
  return new Map(categories.map((category) => [category.slug, category.name]));
}

/** Products matching the search (ignores the category filter). */
export function searchProducts(products: Product[], query: string, categories: Category[]): Product[] {
  const terms = searchTerms(query);
  const names = categoryNames(categories);
  return products.filter((product) =>
    matchesSearch(product, terms, names.get(product.categorySlug)),
  );
}

export function sortProducts(products: Product[], sort: SortOption): Product[] {
  // Copy with original position so ties keep the catalogue order (stable sort).
  const indexed = products.map((product, index) => ({ product, index }));
  // Products without a price sort after priced ones in both directions.
  const unpriced = (p: Product): number => (typeof p.price === "number" ? 0 : 1);
  const priceOf = (p: Product): number => p.price ?? 0;
  indexed.sort((a, b) => {
    switch (sort) {
      case "price-asc":
        return (
          unpriced(a.product) - unpriced(b.product) ||
          priceOf(a.product) - priceOf(b.product) ||
          a.index - b.index
        );
      case "price-desc":
        return (
          unpriced(a.product) - unpriced(b.product) ||
          priceOf(b.product) - priceOf(a.product) ||
          a.index - b.index
        );
      case "name-asc":
        return a.product.name.localeCompare(b.product.name, "en-IN") || a.index - b.index;
      case "featured":
      default:
        return Number(b.product.featured) - Number(a.product.featured) || a.index - b.index;
    }
  });
  return indexed.map(({ product }) => product);
}

/** Applies search, category and sort together. */
export function applyCatalogueState(
  products: Product[],
  state: CatalogueState,
  categories: Category[],
): Product[] {
  const searched = searchProducts(products, state.query, categories);
  const filtered = state.category
    ? searched.filter((product) => product.categorySlug === state.category)
    : searched;
  return sortProducts(filtered, state.sort);
}

/** Count per category slug, plus "all", for the products that match the current search. */
export function countByCategory(
  products: Product[],
  query: string,
  categories: Category[],
): Record<string, number> {
  const searched = searchProducts(products, query, categories);
  const counts: Record<string, number> = { all: searched.length };
  for (const category of categories) counts[category.slug] = 0;
  for (const product of searched) {
    counts[product.categorySlug] = (counts[product.categorySlug] ?? 0) + 1;
  }
  return counts;
}

/** Reads ?q=, ?category= and ?sort= safely; unknown values fall back to defaults. */
export function parseCatalogueParams(
  params: Pick<URLSearchParams, "get">,
  validCategories: string[],
): CatalogueState {
  const category = params.get("category");
  const sort = params.get("sort");
  return {
    query: params.get("q") ?? "",
    category: category && validCategories.includes(category) ? category : null,
    sort: isSortOption(sort) ? sort : DEFAULT_CATALOGUE_STATE.sort,
  };
}

/** Builds the query string, leaving out defaults so URLs stay short. */
export function toCatalogueSearchString(state: CatalogueState): string {
  const params = new URLSearchParams();
  if (state.query) params.set("q", state.query);
  if (state.category) params.set("category", state.category);
  if (state.sort !== DEFAULT_CATALOGUE_STATE.sort) params.set("sort", state.sort);
  return params.toString();
}

export function isSameState(a: CatalogueState, b: CatalogueState): boolean {
  return a.query === b.query && a.category === b.category && a.sort === b.sort;
}
