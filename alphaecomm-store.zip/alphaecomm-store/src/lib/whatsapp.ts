/**
 * WhatsApp helpers.
 *
 * NEXT_PUBLIC_WHATSAPP_NUMBER must be the full international number with
 * country code, digits only — e.g. 919876543210 for an Indian number.
 * Spaces, "+" and dashes are stripped automatically.
 */

const MIN_DIGITS = 10;
const MAX_DIGITS = 15;

/** Returns the configured number as digits, or null if missing/invalid. */
export function getWhatsAppNumber(): string | null {
  const raw = process.env.NEXT_PUBLIC_WHATSAPP_NUMBER ?? "";
  const digits = raw.replace(/\D/g, "");
  if (digits.length < MIN_DIGITS || digits.length > MAX_DIGITS) {
    return null;
  }
  return digits;
}

export function isWhatsAppConfigured(): boolean {
  return getWhatsAppNumber() !== null;
}

/**
 * Builds a wa.me link with an optional pre-filled message.
 * Returns null when the number is not configured, so callers can
 * render a disabled state instead of a broken link.
 */
export function buildWhatsAppUrl(message?: string): string | null {
  const number = getWhatsAppNumber();
  if (!number) {
    return null;
  }
  const base = `https://wa.me/${number}`;
  const text = message?.trim();
  return text ? `${base}?text=${encodeURIComponent(text)}` : base;
}

/** Message for general enquiries. */
export function getGeneralEnquiryMessage(): string {
  return "Hello Alphaecomm Enterprise, I have a question about your products.";
}

export interface ProductMessageDetails {
  name: string;
  sku: string;
  /** Already formatted, e.g. "₹1,299" — the same text the customer saw. Omitted when no price is set. */
  displayPrice?: string;
  url: string;
}

/**
 * Order request for an in-stock product. Asks the business to confirm —
 * it does not imply the order is placed.
 */
export function getProductOrderMessage(details: ProductMessageDetails): string {
  return [
    "Hello Alphaecomm Enterprise,",
    "",
    "I'd like to order this product:",
    `Product: ${details.name}`,
    `SKU: ${details.sku}`,
    ...(details.displayPrice ? [`Price: ${details.displayPrice}`] : []),
    `Link: ${details.url}`,
    "",
    details.displayPrice
      ? "Please confirm availability and shipping charges."
      : "Please share the price, and confirm availability and shipping charges.",
  ].join("\n");
}

/** Enquiry for a product currently shown as out of stock. */
export function getUnavailableProductMessage(details: ProductMessageDetails): string {
  return [
    "Hello Alphaecomm Enterprise,",
    "",
    "This product is shown as out of stock on your website:",
    `Product: ${details.name}`,
    `SKU: ${details.sku}`,
    `Link: ${details.url}`,
    "",
    "Could you let me know if or when it will be available again?",
  ].join("\n");
}
