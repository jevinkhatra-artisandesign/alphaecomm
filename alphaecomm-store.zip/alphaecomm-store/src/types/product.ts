/**
 * Core catalogue models. Every product and category on the site
 * comes from the typed data files in `src/data`.
 */

export interface ProductImage {
  /** Path inside /public, e.g. "/images/products/cooking-pot.jpg" */
  src: string;
  /** Describes what the photo shows, for screen readers. */
  alt: string;
}

export interface ProductSpecification {
  label: string;
  value: string;
}

export interface Product {
  id: string;
  slug: string;
  name: string;
  /** Stock-keeping unit. Must be unique; customers can search by it. */
  sku: string;
  /** Must match a `slug` in src/data/categories.ts */
  categorySlug: string;
  /**
   * Selling price in Indian rupees (whole rupees).
   * Leave out when not confirmed yet: the site shows "Price on request"
   * and the WhatsApp message asks for the price.
   */
  price?: number;
  /** Original price in rupees. Only set this when the business provides it. */
  compareAtPrice?: number;
  shortDescription: string;
  description: string;
  /** First image is used on product cards. */
  images: ProductImage[];
  specifications?: ProductSpecification[];
  inStock: boolean;
  featured: boolean;
  tags: string[];
  /**
   * Development-only flag. Marks placeholder records so they are
   * labelled in the UI and easy to find and replace with real inventory.
   */
  isSample?: boolean;
}

export interface Category {
  id: string;
  slug: string;
  name: string;
  description: string;
  image: ProductImage;
}
