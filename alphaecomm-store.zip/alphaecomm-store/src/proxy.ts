import { NextResponse, type NextRequest } from "next/server";
import { categories } from "@/data/categories";
import { products } from "@/data/products";

/**
 * Returns a real HTTP 404 for unknown product and category URLs.
 *
 * Without this, Next.js still shows the not-found page (with a "noindex" tag),
 * but the response has already started streaming with status 200. Checking
 * the slug here, before rendering starts, lets search engines see a true 404.
 * The check is a lookup in a small in-memory set, so it stays fast.
 */
const knownSlugs = {
  product: new Set(products.map((product) => product.slug)),
  category: new Set(categories.map((category) => category.slug)),
};

export function proxy(request: NextRequest): NextResponse {
  const [, section, slug] = request.nextUrl.pathname.split("/");
  const known = section === "product" ? knownSlugs.product : knownSlugs.category;

  if (!slug || !known.has(decodeURIComponent(slug))) {
    // No route matches this path, so Next.js renders app/not-found.tsx with status 404.
    return NextResponse.rewrite(new URL("/404", request.url));
  }
  return NextResponse.next();
}

export const config = {
  matcher: ["/product/:slug", "/category/:slug"],
};
