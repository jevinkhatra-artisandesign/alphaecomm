import type { Metadata } from "next";
import { ButtonLink } from "@/components/ui/ButtonLink";
import { Container } from "@/components/ui/Container";

export const metadata: Metadata = {
  title: "Page not found",
};

export default function NotFound(): React.JSX.Element {
  return (
    <Container className="py-24 md:py-32">
      <p className="text-sm font-medium text-slate">Error 404</p>
      <h1 className="mt-3 max-w-[18ch] text-title font-semibold text-ink">
        We couldn’t find this page
      </h1>
      <p className="mt-4 max-w-[48ch] text-base leading-relaxed text-slate">
        It may have moved, or it isn’t available yet. Go back to the homepage or browse by category.
      </p>
      <div className="mt-8 flex flex-wrap gap-3">
        <ButtonLink href="/">Go to homepage</ButtonLink>
        <ButtonLink href="/#categories" variant="secondary">
          Browse categories
        </ButtonLink>
      </div>
    </Container>
  );
}
