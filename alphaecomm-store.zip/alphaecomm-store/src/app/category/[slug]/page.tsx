import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { CategoryPage } from "@/components/catalogue/CategoryPage";
import { categories, getCategoryBySlug, getCategoryHref } from "@/data/categories";
import { getCanonical, siteConfig } from "@/lib/site";

// Every category is prerendered as static HTML. Unknown slugs reach notFound().
export function generateStaticParams(): { slug: string }[] {
  return categories.map((category) => ({ slug: category.slug }));
}

export async function generateMetadata({ params }: PageProps<"/category/[slug]">): Promise<Metadata> {
  const category = getCategoryBySlug((await params).slug);
  if (!category) return { title: "Category not found" };
  const href = getCategoryHref(category.slug);
  return {
    title: category.name,
    description: `${category.description} Browse ${category.name.toLowerCase()} from ${siteConfig.name} and order on WhatsApp.`,
    alternates: getCanonical(href),
    openGraph: { title: `${category.name} | ${siteConfig.name}`, description: category.description, url: href },
  };
}

export default async function Page({ params }: PageProps<"/category/[slug]">): Promise<React.JSX.Element> {
  const category = getCategoryBySlug((await params).slug);
  if (!category) notFound();
  return <CategoryPage category={category} />;
}
