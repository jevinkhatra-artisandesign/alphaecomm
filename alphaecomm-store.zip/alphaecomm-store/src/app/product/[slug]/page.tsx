import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { ProductDetailPage } from "@/components/products/ProductDetailPage";
import { getProductBySlug, getProductHref, products } from "@/data/products";
import { formatPrice } from "@/lib/format-price";
import { getCanonical, siteConfig } from "@/lib/site";

// Every product is prerendered as static HTML. Unknown slugs reach notFound().
export function generateStaticParams(): { slug: string }[] {
  return products.map((product) => ({ slug: product.slug }));
}

export async function generateMetadata({ params }: PageProps<"/product/[slug]">): Promise<Metadata> {
  const product = getProductBySlug((await params).slug);
  if (!product) return { title: "Product not found" };
  const href = getProductHref(product.slug);
  const availability = product.inStock ? "In stock" : "Currently out of stock";
  const priceText = typeof product.price === "number" ? ` ${formatPrice(product.price)}.` : "";
  const description = `${product.shortDescription}${priceText} ${availability}. Order on WhatsApp from ${siteConfig.name}.`;
  // Social previews don't support SVG, so only real photos are shared.
  const ogImages = product.images
    .filter((image) => !image.src.toLowerCase().endsWith(".svg"))
    .map((image) => ({ url: image.src, alt: image.alt }));
  return {
    title: product.name,
    description,
    alternates: getCanonical(href),
    openGraph: {
      title: `${product.name} | ${siteConfig.name}`,
      description,
      url: href,
      ...(ogImages.length > 0 ? { images: ogImages } : {}),
    },
  };
}

export default async function Page({ params }: PageProps<"/product/[slug]">): Promise<React.JSX.Element> {
  const product = getProductBySlug((await params).slug);
  if (!product) notFound();
  return <ProductDetailPage product={product} />;
}
