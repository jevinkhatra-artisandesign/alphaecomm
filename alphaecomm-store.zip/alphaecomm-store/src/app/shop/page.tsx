import type { Metadata } from "next";
import { ShopPage } from "@/components/catalogue/ShopPage";
import { getCanonical, siteConfig } from "@/lib/site";

export const metadata: Metadata = {
  title: "Shop All",
  description: `Browse every product from ${siteConfig.name}: kitchenware, home organisation, toys and everyday essentials. Enquire and order on WhatsApp.`,
  alternates: getCanonical("/shop"),
  openGraph: { title: `Shop All | ${siteConfig.name}`, url: "/shop" },
};

export default function Page(): React.JSX.Element {
  return <ShopPage />;
}
