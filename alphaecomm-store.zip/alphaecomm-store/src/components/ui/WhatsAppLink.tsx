import { MessageCircle } from "lucide-react";
import type { ReactNode } from "react";
import { buttonClasses, type ButtonSize, type ButtonVariant } from "@/components/ui/button-styles";
import { buildWhatsAppUrl } from "@/lib/whatsapp";

interface WhatsAppLinkProps {
  /** Pre-filled message text. */
  message?: string;
  /** Visible button text. */
  children: ReactNode;
  /** Full accessible name when the visible text is short, e.g. "Enquire about X on WhatsApp". */
  ariaLabel?: string;
  variant?: ButtonVariant;
  size?: ButtonSize;
  className?: string;
  showIcon?: boolean;
}

/**
 * Opens a WhatsApp chat with the business.
 * If NEXT_PUBLIC_WHATSAPP_NUMBER is not configured, renders a disabled
 * button instead of a broken link.
 */
export function WhatsAppLink({
  message,
  children,
  ariaLabel,
  variant = "whatsapp",
  size = "md",
  className = "",
  showIcon = true,
}: WhatsAppLinkProps): React.JSX.Element {
  const href = buildWhatsAppUrl(message);
  const icon = showIcon ? <MessageCircle aria-hidden="true" className="size-4 shrink-0" /> : null;

  if (!href) {
    return (
      <button
        type="button"
        disabled
        aria-label={ariaLabel ? `${ariaLabel} (WhatsApp not available yet)` : undefined}
        title="WhatsApp ordering is not available yet"
        className={`${buttonClasses(variant, size, true)} ${className}`}
      >
        {icon}
        {children}
      </button>
    );
  }

  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      aria-label={ariaLabel ? `${ariaLabel} (opens WhatsApp)` : undefined}
      className={`${buttonClasses(variant, size)} ${className}`}
    >
      {icon}
      {children}
    </a>
  );
}
