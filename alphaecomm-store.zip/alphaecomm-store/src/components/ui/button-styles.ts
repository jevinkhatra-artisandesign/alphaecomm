export type ButtonVariant = "primary" | "secondary" | "whatsapp";
export type ButtonSize = "sm" | "md";

const base =
  "inline-flex items-center justify-center gap-2 rounded-control font-medium whitespace-nowrap transition-colors duration-150";

const variants: Record<ButtonVariant, string> = {
  primary: "bg-ink text-paper hover:bg-ink/85",
  secondary: "border border-ink/20 bg-paper text-ink hover:border-ink/50",
  whatsapp: "bg-action text-paper hover:bg-action-hover",
};

const sizes: Record<ButtonSize, string> = {
  sm: "h-10 px-3.5 text-sm",
  md: "h-12 px-5 text-[0.9375rem]",
};

const disabled = "cursor-not-allowed bg-stone text-slate border border-line";

/** Shared class names so links and buttons look identical. */
export function buttonClasses(
  variant: ButtonVariant = "primary",
  size: ButtonSize = "md",
  isDisabled = false,
): string {
  return [base, sizes[size], isDisabled ? disabled : variants[variant]].join(" ");
}
