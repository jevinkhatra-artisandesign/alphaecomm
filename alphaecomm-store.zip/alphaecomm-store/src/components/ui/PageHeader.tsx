import type { ReactNode } from "react";
import { Breadcrumbs, type BreadcrumbItem } from "@/components/ui/Breadcrumbs";

interface PageHeaderProps {
  breadcrumbs: BreadcrumbItem[];
  title: string;
  description?: string;
  /** Optional visual on the right (e.g. a category image). */
  aside?: ReactNode;
}

export function PageHeader({ breadcrumbs, title, description, aside }: PageHeaderProps): React.JSX.Element {
  return (
    <div className={`grid gap-8 ${aside ? "md:grid-cols-[1fr_minmax(0,24rem)] md:items-end" : ""}`}>
      <div>
        <Breadcrumbs items={breadcrumbs} />
        <h1 className="mt-5 text-title font-semibold text-ink">{title}</h1>
        {description ? (
          <p className="mt-3 max-w-[56ch] text-base leading-relaxed text-slate">{description}</p>
        ) : null}
      </div>
      {aside}
    </div>
  );
}
