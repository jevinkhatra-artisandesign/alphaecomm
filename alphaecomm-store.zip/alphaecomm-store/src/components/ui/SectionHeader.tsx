import Link from "next/link";
import { Eyebrow } from "@/components/ui/Eyebrow";

interface SectionHeaderProps {
  id: string;
  title: string;
  description?: string;
  eyebrow?: string;
  action?: { label: string; href: string };
}

export function SectionHeader({ id, title, description, eyebrow, action }: SectionHeaderProps): React.JSX.Element {
  return (
    <div className="mb-8 flex flex-col gap-4 sm:mb-10 sm:flex-row sm:items-end sm:justify-between">
      <div className="max-w-xl">
        {eyebrow ? <Eyebrow>{eyebrow}</Eyebrow> : null}
        <h2 id={id} className="text-title font-semibold text-ink">
          {title}
        </h2>
        {description ? <p className="mt-3 text-base leading-relaxed text-slate">{description}</p> : null}
      </div>
      {action ? (
        <Link
          href={action.href}
          className="shrink-0 text-sm font-medium text-ink underline decoration-ink/30 underline-offset-4 hover:decoration-ink"
        >
          {action.label}
        </Link>
      ) : null}
    </div>
  );
}
