import type { ReactNode } from "react";

interface ContainerProps {
  children: ReactNode;
  className?: string;
}

/** Centres content and applies the site's horizontal padding. */
export function Container({ children, className = "" }: ContainerProps): React.JSX.Element {
  return (
    <div className={`mx-auto w-full max-w-site px-5 sm:px-8 ${className}`}>{children}</div>
  );
}
