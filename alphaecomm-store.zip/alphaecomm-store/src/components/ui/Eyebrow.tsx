import type { ReactNode } from "react";

/** Small coloured label above a section title. */
export function Eyebrow({ children }: { children: ReactNode }): React.JSX.Element {
  return <p className="mb-3 text-xs font-semibold tracking-[0.08em] text-clay uppercase">{children}</p>;
}
