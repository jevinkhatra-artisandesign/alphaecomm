import { WhatsAppLink } from "@/components/ui/WhatsAppLink";
import { getProductHref } from "@/data/products";
import { formatPrice } from "@/lib/format-price";
import { getAbsoluteUrl } from "@/lib/site";
import { getProductOrderMessage, getUnavailableProductMessage } from "@/lib/whatsapp";
import type { Product } from "@/types/product";

interface WhatsAppOrderButtonProps {
  product: Pick<Product, "name" | "slug" | "sku" | "price" | "inStock">;
  /** "card": compact "Enquire" button. "detail": prominent button on the product page. */
  context?: "card" | "detail";
  className?: string;
}

/**
 * Product-specific WhatsApp action.
 * In stock → order request (business confirms availability and shipping).
 * Out of stock → availability enquiry that says the product is unavailable.
 */
export function WhatsAppOrderButton({
  product,
  context = "card",
  className = "",
}: WhatsAppOrderButtonProps): React.JSX.Element {
  const details = {
    name: product.name,
    sku: product.sku,
    displayPrice: typeof product.price === "number" ? formatPrice(product.price) : undefined,
    url: getAbsoluteUrl(getProductHref(product.slug)),
  };
  const isDetail = context === "detail";

  if (!product.inStock) {
    return (
      <WhatsAppLink
        message={getUnavailableProductMessage(details)}
        ariaLabel={`Ask about availability of ${product.name}, currently out of stock, on WhatsApp`}
        variant="secondary"
        size={isDetail ? "md" : "sm"}
        className={className}
      >
        {isDetail ? "Ask about availability" : "Check availability"}
      </WhatsAppLink>
    );
  }

  return (
    <WhatsAppLink
      message={getProductOrderMessage(details)}
      ariaLabel={
        isDetail ? `Order ${product.name} on WhatsApp` : `Enquire about ${product.name} on WhatsApp`
      }
      size={isDetail ? "md" : "sm"}
      className={className}
    >
      {isDetail ? "Order on WhatsApp" : "Enquire"}
    </WhatsAppLink>
  );
}
