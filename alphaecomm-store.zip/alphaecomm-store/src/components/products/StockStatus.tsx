interface StockStatusProps {
  inStock: boolean;
}

/** Text + dot, so status never relies on colour alone. */
export function StockStatus({ inStock }: StockStatusProps): React.JSX.Element {
  return (
    <p className={`flex items-center gap-1.5 text-xs font-medium ${inStock ? "text-instock" : "text-slate"}`}>
      <span
        aria-hidden="true"
        className={`size-1.5 rounded-full ${inStock ? "bg-instock" : "border border-slate"}`}
      />
      {inStock ? "In stock" : "Out of stock"}
    </p>
  );
}
