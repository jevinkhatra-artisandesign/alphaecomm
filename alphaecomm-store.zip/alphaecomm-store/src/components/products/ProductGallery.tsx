"use client";

import { ImageOff } from "lucide-react";
import Image from "next/image";
import { useState } from "react";
import type { ProductImage } from "@/types/product";

interface ProductGalleryProps {
  images: ProductImage[];
  productName: string;
  isSample?: boolean;
}

/** Main image with clickable thumbnails. Thumbnails only appear when there are several images. */
export function ProductGallery({ images, productName, isSample = false }: ProductGalleryProps): React.JSX.Element {
  const [selected, setSelected] = useState(0);
  const current = images[selected] ?? images[0];

  return (
    <div>
      <div className="relative aspect-square overflow-hidden rounded-media bg-stone">
        {current ? (
          <Image
            key={current.src}
            src={current.src}
            alt={current.alt}
            fill
            preload={selected === 0}
            sizes="(min-width: 1024px) 36rem, (min-width: 768px) 50vw, 100vw"
            className="object-cover"
          />
        ) : (
          <div className="flex h-full flex-col items-center justify-center gap-3 text-slate">
            <ImageOff aria-hidden="true" className="size-8" />
            <p className="text-sm">Photo of {productName} coming soon</p>
          </div>
        )}
        {isSample ? (
          <span className="absolute left-3 top-3 rounded-[3px] bg-paper/90 px-2 py-0.5 text-xs font-medium text-slate">
            Sample
          </span>
        ) : null}
      </div>

      {images.length > 1 ? (
        <ul className="mt-3 grid grid-cols-4 gap-3 sm:grid-cols-5" aria-label={`${productName} images`}>
          {images.map((image, index) => {
            const active = index === selected;
            return (
              <li key={image.src}>
                <button
                  type="button"
                  onClick={() => setSelected(index)}
                  aria-label={`Show image ${index + 1} of ${images.length}: ${image.alt}`}
                  aria-pressed={active}
                  className={`relative block aspect-square w-full overflow-hidden rounded-media bg-stone ring-offset-2 transition-shadow ${
                    active ? "ring-2 ring-ink" : "ring-1 ring-line hover:ring-ink/40"
                  }`}
                >
                  <Image src={image.src} alt="" fill sizes="6rem" className="object-cover" />
                </button>
              </li>
            );
          })}
        </ul>
      ) : null}
    </div>
  );
}
