import Link from "next/link";
import { ProductGallery } from "@/components/products/ProductGallery";
import { ProductGrid } from "@/components/products/ProductGrid";
import { ProductPrice } from "@/components/products/ProductPrice";
import { StockStatus } from "@/components/products/StockStatus";
import { WhatsAppOrderButton } from "@/components/products/WhatsAppOrderButton";
import { Breadcrumbs } from "@/components/ui/Breadcrumbs";
import { Container } from "@/components/ui/Container";
import { SectionHeader } from "@/components/ui/SectionHeader";
import { getCategoryBySlug, getCategoryHref } from "@/data/categories";
import { getRelatedProducts } from "@/data/products";
import { getCategoryTone } from "@/lib/category-tones";
import type { Product } from "@/types/product";

export function ProductDetailPage({ product }: { product: Product }): React.JSX.Element {
  const category = getCategoryBySlug(product.categorySlug);
  const related = getRelatedProducts(product);
  // Section ids include the slug: recently visited pages stay mounted (hidden), so ids must not repeat.
  const ids = { details: `details-${product.slug}`, specs: `specs-${product.slug}`, related: `related-${product.slug}` };
  const visibleTags = product.tags.filter((tag) => tag !== "sample");

  return (
    <>
      <Container className="py-10 md:py-14">
        <Breadcrumbs
          items={[
            { label: "Home", href: "/" },
            { label: "Shop All", href: "/shop" },
            ...(category ? [{ label: category.name, href: getCategoryHref(category.slug) }] : []),
            { label: product.name },
          ]}
        />

        <div className="mt-8 grid gap-10 md:grid-cols-2 md:gap-12 lg:gap-20">
          <ProductGallery images={product.images} productName={product.name} isSample={product.isSample} />

          <div className="md:pt-2">
            {category ? (
              <Link
                href={getCategoryHref(category.slug)}
                className={`inline-flex h-8 items-center rounded-full px-3 text-xs font-semibold text-ink hover:underline hover:underline-offset-4 ${getCategoryTone(category.slug).surface}`}
              >
                {category.name}
              </Link>
            ) : null}
            <h1 className="mt-4 text-title font-semibold text-ink">{product.name}</h1>
            <p className="mt-2 text-sm text-slate">
              SKU <span className="font-medium text-ink">{product.sku}</span>
            </p>

            <div className="mt-6">
              <ProductPrice price={product.price} compareAtPrice={product.compareAtPrice} size="lg" />
            </div>
            <div className="mt-2">
              <StockStatus inStock={product.inStock} />
            </div>

            <p className="mt-6 max-w-[52ch] text-base leading-relaxed text-ink">{product.shortDescription}</p>

            <div className="mt-8 border-y border-line py-6">
              <WhatsAppOrderButton product={product} context="detail" className="w-full sm:w-auto" />
              <p className="mt-3 max-w-[48ch] text-sm leading-relaxed text-slate">
                {product.inStock
                  ? "Opens WhatsApp with the product details filled in. We’ll reply to confirm availability, shipping charges and payment by UPI before your order is placed."
                  : "This product is currently out of stock. Message us on WhatsApp to ask when it will be available again."}
              </p>
            </div>

            <section aria-labelledby={ids.details} className="mt-8">
              <h2 id={ids.details} className="text-base font-semibold text-ink">
                Product details
              </h2>
              <p className="mt-3 max-w-[60ch] whitespace-pre-line text-[0.9375rem] leading-relaxed text-slate">
                {product.description}
              </p>
            </section>

            {product.specifications && product.specifications.length > 0 ? (
              <section aria-labelledby={ids.specs} className="mt-8">
                <h2 id={ids.specs} className="text-base font-semibold text-ink">
                  Specifications
                </h2>
                <dl className="mt-3 divide-y divide-line border-y border-line">
                  {product.specifications.map((spec) => (
                    <div key={spec.label} className="grid grid-cols-[minmax(0,10rem)_1fr] gap-4 py-3 text-[0.9375rem]">
                      <dt className="text-slate">{spec.label}</dt>
                      <dd className="text-ink">{spec.value}</dd>
                    </div>
                  ))}
                </dl>
              </section>
            ) : null}

            {visibleTags.length > 0 ? (
              <div className="mt-8">
                <h2 className="sr-only">Tags</h2>
                <ul className="flex flex-wrap gap-2">
                  {visibleTags.map((tag) => (
                    <li key={tag}>
                      <Link
                        href={`/shop?q=${encodeURIComponent(tag)}`}
                        className="inline-flex h-8 items-center rounded-control bg-stone px-3 text-xs font-medium text-slate hover:text-ink"
                      >
                        {tag}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            ) : null}
          </div>
        </div>
      </Container>

      {related.length > 0 ? (
        <section aria-labelledby={ids.related} className="bg-linen py-16 md:py-20">
          <Container>
            <SectionHeader
              id={ids.related}
              title="You may also like"
              action={category ? { label: `View all ${category.name}`, href: getCategoryHref(category.slug) } : undefined}
            />
            <ProductGrid products={related} />
          </Container>
        </section>
      ) : null}
    </>
  );
}
