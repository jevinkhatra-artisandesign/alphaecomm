import { ProductCard } from "@/components/products/ProductCard";
import type { Product } from "@/types/product";

interface ProductGridProps {
  products: Product[];
  /** Number of leading cards whose images should load early. */
  preloadCount?: number;
  emptyMessage?: string;
  /** "sidebar" uses fewer columns when the grid sits beside a filter sidebar. */
  layout?: "full" | "sidebar";
}

const gridLayouts = {
  full: "grid-cols-2 md:grid-cols-3 lg:grid-cols-4",
  sidebar: "grid-cols-2 md:grid-cols-3",
} as const;

export function ProductGrid({
  products,
  preloadCount = 0,
  emptyMessage = "No products here yet. Check back soon or message us on WhatsApp.",
  layout = "full",
}: ProductGridProps): React.JSX.Element {
  if (products.length === 0) {
    return <p className="text-sm text-slate">{emptyMessage}</p>;
  }

  return (
    <ul className={`grid gap-x-4 gap-y-10 lg:gap-x-6 ${gridLayouts[layout]}`}>
      {products.map((product, index) => (
        <li key={product.id}>
          <ProductCard product={product} preloadImage={index < preloadCount} />
        </li>
      ))}
    </ul>
  );
}
