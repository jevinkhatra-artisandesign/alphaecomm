import { formatPrice } from "@/lib/format-price";

interface ProductPriceProps {
  /** Omitted when the price isn't confirmed yet. */
  price?: number;
  compareAtPrice?: number;
  size?: "md" | "lg";
}

/**
 * Shows the price, or "Price on request" when none is set.
 * The compare-at price only appears when it is provided and higher than the price.
 */
export function ProductPrice({ price, compareAtPrice, size = "md" }: ProductPriceProps): React.JSX.Element {
  const textSize = size === "lg" ? "text-xl" : "text-[0.9375rem]";

  if (typeof price !== "number") {
    return (
      <p className={`${textSize} font-medium text-slate`}>
        Price on request
      </p>
    );
  }

  const showCompare = typeof compareAtPrice === "number" && compareAtPrice > price;

  return (
    <p className={`flex flex-wrap items-baseline gap-x-2 ${textSize}`}>
      <span className="font-semibold text-ink">
        <span className="sr-only">{showCompare ? "Sale price " : "Price "}</span>
        {formatPrice(price)}
      </span>
      {showCompare ? (
        <>
          <span className={`text-slate line-through ${size === "lg" ? "text-base" : "text-sm"}`}>
            <span className="sr-only">Original price </span>
            {formatPrice(compareAtPrice)}
          </span>
          <span className={`font-semibold text-instock ${size === "lg" ? "text-base" : "text-sm"}`}>
            {Math.round(((compareAtPrice - price) / compareAtPrice) * 100)}% off
          </span>
        </>
      ) : null}
    </p>
  );
}
