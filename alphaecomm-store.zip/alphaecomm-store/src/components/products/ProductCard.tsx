import Image from "next/image";
import Link from "next/link";
import { ProductPrice } from "@/components/products/ProductPrice";
import { StockStatus } from "@/components/products/StockStatus";
import { WhatsAppOrderButton } from "@/components/products/WhatsAppOrderButton";
import { getProductHref } from "@/data/products";
import type { Product } from "@/types/product";

interface ProductCardProps {
  product: Product;
  /** Set true for cards visible on first load to load their image early. */
  preloadImage?: boolean;
}

export function ProductCard({ product, preloadImage = false }: ProductCardProps): React.JSX.Element {
  const image = product.images[0];

  return (
    <article className="flex h-full flex-col">
      {/* One link for image + name keeps a single tab stop per product. */}
      <Link href={getProductHref(product.slug)} className="group block">
        <div className="relative aspect-square overflow-hidden rounded-media bg-stone">
          {image ? (
            <Image
              src={image.src}
              alt={image.alt}
              fill
              preload={preloadImage}
              sizes="(min-width: 1024px) 18rem, (min-width: 768px) 30vw, 50vw"
              className="object-cover"
            />
          ) : null}
          {product.isSample ? (
            <span className="absolute left-2.5 top-2.5 rounded-[3px] bg-paper/90 px-1.5 py-0.5 text-xs font-medium text-slate">
              Sample
            </span>
          ) : null}
        </div>
        <h3 className="mt-3.5 text-[0.9375rem] font-medium leading-snug text-ink group-hover:underline group-hover:underline-offset-4">
          {product.name}
        </h3>
      </Link>

      <div className="mt-1.5 flex flex-1 flex-col">
        <ProductPrice price={product.price} compareAtPrice={product.compareAtPrice} />
        <div className="mt-1.5">
          <StockStatus inStock={product.inStock} />
        </div>
        <div className="mt-auto pt-4">
          <WhatsAppOrderButton product={product} className="w-full sm:w-auto" />
        </div>
      </div>
    </article>
  );
}
