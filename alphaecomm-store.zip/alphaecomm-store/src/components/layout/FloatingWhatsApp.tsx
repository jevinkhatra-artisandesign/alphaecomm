import { MessageCircle } from "lucide-react";
import { buildWhatsAppUrl, getGeneralEnquiryMessage } from "@/lib/whatsapp";

/**
 * Always-visible WhatsApp button in the bottom-right corner.
 * Phones: round icon button. Larger screens: icon + "Chat on WhatsApp".
 * Renders nothing until NEXT_PUBLIC_WHATSAPP_NUMBER is configured.
 */
export function FloatingWhatsApp(): React.JSX.Element | null {
  const href = buildWhatsAppUrl(getGeneralEnquiryMessage());
  if (!href) return null;

  return (
    // A labelled landmark, so screen-reader users can find it when navigating by region.
    <aside aria-label="Quick contact">
      <a
        href={href}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Chat with us on WhatsApp (opens WhatsApp)"
        className="fixed right-4 bottom-[calc(1rem+env(safe-area-inset-bottom,0px))] z-40 inline-flex size-14 items-center justify-center gap-2 rounded-full bg-action text-paper shadow-[0_6px_20px_-6px_rgba(23,63,52,0.55)] transition-colors hover:bg-action-hover sm:right-6 sm:bottom-[calc(1.5rem+env(safe-area-inset-bottom,0px))] sm:size-auto sm:h-12 sm:px-5"
      >
        <MessageCircle aria-hidden="true" className="size-6 shrink-0 sm:size-5" />
        <span className="sr-only sm:not-sr-only sm:text-[0.9375rem] sm:font-medium">Chat on WhatsApp</span>
      </a>
    </aside>
  );
}
