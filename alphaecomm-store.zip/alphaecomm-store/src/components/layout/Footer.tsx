import Link from "next/link";
import { Container } from "@/components/ui/Container";
import { WhatsAppLink } from "@/components/ui/WhatsAppLink";
import { categories, getCategoryHref } from "@/data/categories";
import { mainNav, policyNav, siteConfig, type NavItem } from "@/lib/site";
import { getGeneralEnquiryMessage } from "@/lib/whatsapp";

function FooterLinks({ title, items }: { title: string; items: NavItem[] }): React.JSX.Element {
  return (
    <div>
      <h2 className="text-sm font-semibold text-ink">{title}</h2>
      <ul className="mt-4 space-y-2.5">
        {items.map((item) => (
          <li key={item.href}>
            <Link href={item.href} className="text-sm text-slate transition-colors hover:text-ink">
              {item.label}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}

export function Footer(): React.JSX.Element {
  const categoryLinks: NavItem[] = categories.map((category) => ({
    label: category.name,
    href: getCategoryHref(category.slug),
  }));

  return (
    <footer className="border-t border-line bg-paper">
      <Container className="grid gap-10 py-14 sm:grid-cols-2 lg:grid-cols-[1.4fr_1fr_1fr_1fr]">
        <div className="max-w-xs">
          <p className="text-lg font-semibold tracking-[-0.01em] text-ink">{siteConfig.name}</p>
          <p className="mt-3 text-sm leading-relaxed text-slate">
            Kitchenware, home organisation, toys and everyday essentials. Orders are placed on
            WhatsApp.
          </p>
          <WhatsAppLink
            message={getGeneralEnquiryMessage()}
            size="sm"
            ariaLabel="Chat with us on WhatsApp"
            className="mt-5"
          >
            Chat on WhatsApp
          </WhatsAppLink>
        </div>
        <FooterLinks title="Explore" items={mainNav} />
        <FooterLinks title="Categories" items={categoryLinks} />
        <FooterLinks title="Policies" items={policyNav} />
      </Container>
      <div className="border-t border-line">
        <Container className="pt-6 pb-24 sm:pb-6">
          <p className="text-xs text-slate">© {siteConfig.name}. All rights reserved.</p>
        </Container>
      </div>
    </footer>
  );
}
