import Link from "next/link";
import { BrandMark } from "@/components/layout/BrandMark";
import { MobileNav } from "@/components/layout/MobileNav";
import { SearchForm } from "@/components/layout/SearchForm";
import { Container } from "@/components/ui/Container";
import { WhatsAppLink } from "@/components/ui/WhatsAppLink";
import { mainNav } from "@/lib/site";
import { getGeneralEnquiryMessage } from "@/lib/whatsapp";

export function Header(): React.JSX.Element {
  const enquiry = getGeneralEnquiryMessage();

  return (
    <header className="sticky top-0 z-40 border-b border-line bg-paper/95 backdrop-blur-sm">
      <Container className="relative flex h-16 items-center gap-6 md:h-[4.5rem]">
        <BrandMark />

        <nav aria-label="Main" className="hidden md:block">
          <ul className="flex items-center gap-7">
            {mainNav.map((item) => (
              <li key={item.href}>
                <Link
                  href={item.href}
                  className="text-sm font-medium text-slate transition-colors hover:text-ink"
                >
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        <div className="ml-auto flex items-center gap-2 sm:gap-3">
          <SearchForm id="header-search" className="hidden w-56 lg:block" />
          <WhatsAppLink
            message={enquiry}
            size="sm"
            ariaLabel="Chat with us on WhatsApp"
            className="max-[379px]:w-10 max-[379px]:px-0"
          >
            <span className="max-[379px]:sr-only">WhatsApp</span>
          </WhatsAppLink>
          <MobileNav items={mainNav}>
            <SearchForm id="mobile-search" />
            <WhatsAppLink message={enquiry} ariaLabel="Chat with us on WhatsApp" className="w-full">
              Chat on WhatsApp
            </WhatsAppLink>
          </MobileNav>
        </div>
      </Container>
    </header>
  );
}
