import { isWhatsAppConfigured } from "@/lib/whatsapp";

/** Shown only in development, when the WhatsApp number is missing. */
export function DevNotice(): React.JSX.Element | null {
  if (process.env.NODE_ENV !== "development" || isWhatsAppConfigured()) {
    return null;
  }
  return (
    <div className="bg-ink px-5 py-2 text-center text-xs text-paper/90 sm:px-8">
      Development: set <code className="font-semibold">NEXT_PUBLIC_WHATSAPP_NUMBER</code> in{" "}
      <code className="font-semibold">.env.local</code> to enable WhatsApp buttons. See{" "}
      <code className="font-semibold">.env.example</code>.
    </div>
  );
}
