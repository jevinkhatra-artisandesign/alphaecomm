import { Search } from "lucide-react";

interface SearchFormProps {
  id: string;
  className?: string;
}

/**
 * Plain HTML search form — works without JavaScript.
 * Submits to /shop?q=..., which is implemented in the next phase.
 */
export function SearchForm({ id, className = "" }: SearchFormProps): React.JSX.Element {
  return (
    <form action="/shop" method="get" role="search" className={`relative ${className}`}>
      <label htmlFor={id} className="sr-only">
        Search products
      </label>
      <input
        id={id}
        name="q"
        type="search"
        placeholder="Search products"
        autoComplete="off"
        className="h-10 w-full rounded-control border border-line bg-paper pl-3.5 pr-10 text-base text-ink placeholder:text-slate focus:border-ink/40"
      />
      <button
        type="submit"
        aria-label="Search"
        className="absolute inset-y-0 right-0 flex w-10 items-center justify-center text-slate hover:text-ink"
      >
        <Search aria-hidden="true" className="size-4" />
      </button>
    </form>
  );
}
