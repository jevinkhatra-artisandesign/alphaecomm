import Link from "next/link";

/**
 * Text-based brand treatment, used until an official logo file is supplied.
 * To use a logo: add it to public/images/brand/ and swap the text for <Image />.
 */
export function BrandMark(): React.JSX.Element {
  return (
    <Link href="/" className="flex flex-col leading-none" aria-label="Alphaecomm Enterprise, home">
      <span className="text-[1.3125rem] font-semibold tracking-[-0.02em] text-ink">Alphaecomm</span>
      <span className="mt-1 text-xs font-medium tracking-[0.04em] text-slate">
        Enterprise
      </span>
    </Link>
  );
}
