"use client";

import { useId } from "react";
import { getCategoryTone } from "@/lib/category-tones";
import type { Category } from "@/types/product";

interface CategoryFilterProps {
  categories: Category[];
  selected: string | null;
  counts: Record<string, number>;
  onSelect: (slug: string | null) => void;
}

interface Option {
  slug: string | null;
  label: string;
  count: number;
}

function buildOptions(categories: Category[], counts: Record<string, number>): Option[] {
  return [
    { slug: null, label: "All Products", count: counts.all ?? 0 },
    ...categories.map((category) => ({
      slug: category.slug,
      label: category.name,
      count: counts[category.slug] ?? 0,
    })),
  ];
}

/** Coloured category marker; "All Products" gets none. */
function Dot({ slug }: { slug: string | null }): React.JSX.Element | null {
  if (!slug) return null;
  return <span aria-hidden="true" className={`size-2 shrink-0 rounded-full ${getCategoryTone(slug).dot}`} />;
}

/** Desktop: vertical list in the sidebar. */
export function CategoryFilterList({
  categories,
  selected,
  counts,
  onSelect,
}: CategoryFilterProps): React.JSX.Element {
  const options = buildOptions(categories, counts);
  const headingId = useId();
  return (
    <div role="group" aria-labelledby={headingId}>
      <h2 id={headingId} className="text-sm font-semibold text-ink">
        Category
      </h2>
      <ul className="mt-3 space-y-0.5">
        {options.map((option) => {
          const active = option.slug === selected;
          return (
            <li key={option.slug ?? "all"}>
              <button
                type="button"
                aria-pressed={active}
                onClick={() => onSelect(option.slug)}
                className={`flex w-full items-center justify-between rounded-control px-3 py-2 text-left text-sm transition-colors ${
                  active ? "bg-stone font-medium text-ink" : "text-slate hover:bg-stone/60 hover:text-ink"
                }`}
              >
                <span className="flex items-center gap-2.5">
                  <Dot slug={option.slug} />
                  {option.label}
                </span>
                <span className="tabular-nums text-xs text-slate">{option.count}</span>
              </button>
            </li>
          );
        })}
      </ul>
    </div>
  );
}

/** Mobile and tablet: horizontally scrollable chips. */
export function CategoryFilterChips({
  categories,
  selected,
  counts,
  onSelect,
}: CategoryFilterProps): React.JSX.Element {
  const options = buildOptions(categories, counts);
  return (
    <div role="group" aria-label="Filter by category" className="-mx-5 overflow-x-auto px-5 sm:-mx-8 sm:px-8 [scrollbar-width:none]">
      <ul className="flex w-max gap-2 pb-1">
        {options.map((option) => {
          const active = option.slug === selected;
          return (
            <li key={option.slug ?? "all"}>
              <button
                type="button"
                aria-pressed={active}
                onClick={() => onSelect(option.slug)}
                className={`inline-flex h-10 items-center gap-2 rounded-full border px-4 text-sm whitespace-nowrap transition-colors ${
                  active
                    ? "border-ink bg-ink text-paper"
                    : "border-line bg-paper text-ink hover:border-ink/40"
                }`}
              >
                <Dot slug={option.slug} />
                {option.label}
                <span className={`tabular-nums text-xs ${active ? "text-paper/70" : "text-slate"}`}>
                  {option.count}
                </span>
              </button>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
