"use client";

import { Search, X } from "lucide-react";
import { useId, useRef } from "react";

interface CatalogueSearchProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
}

/** Search field that filters as you type. Enter does nothing extra — results are already live. */
export function CatalogueSearch({
  value,
  onChange,
  placeholder = "Search by name, SKU or keyword",
}: CatalogueSearchProps): React.JSX.Element {
  const inputRef = useRef<HTMLInputElement>(null);
  // Unique per instance: Next.js keeps recently visited pages mounted (hidden), so fixed ids could clash.
  const inputId = useId();

  return (
    <form role="search" onSubmit={(event) => event.preventDefault()} className="relative w-full">
      <label htmlFor={inputId} className="sr-only">
        Search products in this list
      </label>
      <Search
        aria-hidden="true"
        className="pointer-events-none absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-slate"
      />
      <input
        ref={inputRef}
        id={inputId}
        type="search"
        value={value}
        onChange={(event) => onChange(event.target.value)}
        placeholder={placeholder}
        autoComplete="off"
        className="h-11 w-full rounded-control border border-line bg-paper pl-10 pr-11 text-base text-ink placeholder:text-slate focus:border-ink/40 [&::-webkit-search-cancel-button]:hidden"
      />
      {value ? (
        <button
          type="button"
          aria-label="Clear search"
          onClick={() => {
            onChange("");
            inputRef.current?.focus();
          }}
          className="absolute inset-y-0 right-0 flex w-11 items-center justify-center text-slate hover:text-ink"
        >
          <X aria-hidden="true" className="size-4" />
        </button>
      ) : null}
    </form>
  );
}
