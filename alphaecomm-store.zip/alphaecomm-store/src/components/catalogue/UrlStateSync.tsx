"use client";

import { useSearchParams } from "next/navigation";
import { useEffect } from "react";
import { parseCatalogueParams, type CatalogueState } from "@/lib/catalogue";

interface UrlStateSyncProps {
  validCategories: string[];
  /** Receives the parsed state plus the raw query string it came from. */
  onUrlState: (state: CatalogueState, rawQuery: string) => void;
}

/**
 * Reads ?q=, ?category= and ?sort= from the address bar and hands them to the
 * catalogue. Kept separate (inside <Suspense>) so the product grid itself can be
 * prerendered as static HTML for search engines.
 */
export function UrlStateSync({ validCategories, onUrlState }: UrlStateSyncProps): null {
  const searchParams = useSearchParams();

  useEffect(() => {
    onUrlState(parseCatalogueParams(searchParams, validCategories), searchParams.toString());
  }, [searchParams, validCategories, onUrlState]);

  return null;
}
