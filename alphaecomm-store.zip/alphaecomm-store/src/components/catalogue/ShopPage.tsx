import { ProductCatalogue } from "@/components/catalogue/ProductCatalogue";
import { Container } from "@/components/ui/Container";
import { PageHeader } from "@/components/ui/PageHeader";
import { categories } from "@/data/categories";
import { products } from "@/data/products";

export function ShopPage(): React.JSX.Element {
  return (
    <>
      <div className="bg-sage">
        <Container className="py-10 md:py-14">
          <PageHeader
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Shop All" }]}
        title="Shop All"
        description="Every product in the catalogue. Search, filter by category, and enquire about anything on WhatsApp."
          />
        </Container>
      </div>
      <Container className="py-10 md:py-12">
        <ProductCatalogue products={products} categories={categories} />
      </Container>
    </>
  );
}
