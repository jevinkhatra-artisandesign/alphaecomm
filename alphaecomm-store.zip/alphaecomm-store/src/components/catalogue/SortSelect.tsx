"use client";

import { ChevronDown } from "lucide-react";
import { useId } from "react";
import { SORT_OPTIONS, type SortOption } from "@/lib/catalogue";

interface SortSelectProps {
  value: SortOption;
  onChange: (value: SortOption) => void;
}

export function SortSelect({ value, onChange }: SortSelectProps): React.JSX.Element {
  const selectId = useId();
  return (
    <div className="flex items-center gap-2">
      <label htmlFor={selectId} className="shrink-0 text-sm text-slate">
        Sort by
      </label>
      <div className="relative">
        <select
          id={selectId}
          value={value}
          onChange={(event) => onChange(event.target.value as SortOption)}
          className="h-11 appearance-none rounded-control border border-line bg-paper pl-3.5 pr-9 text-base font-medium text-ink hover:border-ink/40"
        >
          {SORT_OPTIONS.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
        <ChevronDown
          aria-hidden="true"
          className="pointer-events-none absolute right-3 top-1/2 size-4 -translate-y-1/2 text-slate"
        />
      </div>
    </div>
  );
}
