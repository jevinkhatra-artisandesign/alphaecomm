"use client";

import { Suspense, useCallback, useMemo, useRef, useState } from "react";
import { CatalogueSearch } from "@/components/catalogue/CatalogueSearch";
import { CategoryFilterChips, CategoryFilterList } from "@/components/catalogue/CategoryFilter";
import { SortSelect } from "@/components/catalogue/SortSelect";
import { UrlStateSync } from "@/components/catalogue/UrlStateSync";
import { ProductGrid } from "@/components/products/ProductGrid";
import { buttonClasses } from "@/components/ui/button-styles";
import { WhatsAppLink } from "@/components/ui/WhatsAppLink";
import { getGeneralEnquiryMessage } from "@/lib/whatsapp";
import {
  applyCatalogueState,
  countByCategory,
  DEFAULT_CATALOGUE_STATE,
  isSameState,
  toCatalogueSearchString,
  type CatalogueState,
} from "@/lib/catalogue";
import type { Category, Product } from "@/types/product";

interface ProductCatalogueProps {
  products: Product[];
  categories: Category[];
  /** On a category page: fixes the category and hides the category filter. */
  lockedCategory?: string;
}

function formatCount(count: number): string {
  return `${count} ${count === 1 ? "product" : "products"}`;
}

/**
 * Interactive product listing: search, category filter and sort.
 * State is mirrored in the URL (?q=&category=&sort=) without reloading the page,
 * so filtered views can be shared and survive refresh.
 */
export function ProductCatalogue({
  products,
  categories,
  lockedCategory,
}: ProductCatalogueProps): React.JSX.Element {
  const [state, setState] = useState<CatalogueState>(DEFAULT_CATALOGUE_STATE);
  const validCategories = useMemo(() => categories.map((category) => category.slug), [categories]);
  const showCategoryFilter = !lockedCategory;

  const effectiveState = useMemo<CatalogueState>(
    () => (lockedCategory ? { ...state, category: lockedCategory } : state),
    [state, lockedCategory],
  );
  const results = useMemo(
    () => applyCatalogueState(products, effectiveState, categories),
    [products, effectiveState, categories],
  );
  const counts = useMemo(
    () => countByCategory(products, state.query, categories),
    [products, state.query, categories],
  );

  /**
   * Query strings this component wrote itself, oldest first. Next.js reports each
   * URL change back a moment later; applying those echoes would overwrite newer
   * keystrokes (fast typing dropped letters). Echoes are skipped; only outside
   * changes — header search, Back button, a shared link — update the state.
   */
  const pendingWrites = useRef<string[]>([]);

  const handleUrlState = useCallback((next: CatalogueState, rawQuery: string) => {
    const index = pendingWrites.current.indexOf(rawQuery);
    if (index !== -1) {
      pendingWrites.current.splice(0, index + 1);
      return;
    }
    pendingWrites.current = [];
    setState((prev) => (isSameState(prev, next) ? prev : next));
  }, []);

  function update(partial: Partial<CatalogueState>): void {
    const next = { ...state, ...partial };
    setState(next);
    const query = toCatalogueSearchString(lockedCategory ? { ...next, category: null } : next);
    const path = window.location.pathname;
    pendingWrites.current.push(query);
    window.history.replaceState(null, "", query ? `${path}?${query}` : path);
  }

  const hasActiveFilters = state.query.trim() !== "" || (showCategoryFilter && state.category !== null);
  const trimmedQuery = state.query.trim();

  const filterProps = {
    categories,
    selected: state.category,
    counts,
    onSelect: (slug: string | null) => update({ category: slug }),
  };

  if (products.length === 0) {
    return (
      <div className="rounded-media border border-dashed border-line px-6 py-14 text-center">
        <h2 className="text-lg font-semibold text-ink">New products coming soon</h2>
        <p className="mx-auto mt-2 max-w-[44ch] text-[0.9375rem] leading-relaxed text-slate">
          We’re adding products to this category. Looking for something specific? Ask us on WhatsApp.
        </p>
        <WhatsAppLink message={getGeneralEnquiryMessage()} ariaLabel="Ask us on WhatsApp" className="mt-6">
          Ask on WhatsApp
        </WhatsAppLink>
      </div>
    );
  }

  return (
    <div className={showCategoryFilter ? "lg:grid lg:grid-cols-[13rem_1fr] lg:gap-12" : ""}>
      <Suspense fallback={null}>
        <UrlStateSync validCategories={validCategories} onUrlState={handleUrlState} />
      </Suspense>

      {showCategoryFilter ? (
        <aside className="hidden lg:block">
          <div className="sticky top-24">
            <CategoryFilterList {...filterProps} />
          </div>
        </aside>
      ) : null}

      <div className="min-w-0">
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div className="md:max-w-sm md:flex-1">
            <CatalogueSearch value={state.query} onChange={(query) => update({ query })} />
          </div>
          <SortSelect value={state.sort} onChange={(sort) => update({ sort })} />
        </div>

        {showCategoryFilter ? (
          <div className="mt-4 lg:hidden">
            <CategoryFilterChips {...filterProps} />
          </div>
        ) : null}

        <div className="mt-6 mb-6 flex items-center justify-between gap-4 border-b border-line pb-4">
          <p aria-live="polite" className="text-sm text-slate">
            <span className="font-medium text-ink">{formatCount(results.length)}</span>
            {trimmedQuery ? <> for “{trimmedQuery}”</> : null}
          </p>
          {hasActiveFilters && results.length > 0 ? (
            <button
              type="button"
              onClick={() => update({ query: "", category: null })}
              className="text-sm font-medium text-ink underline decoration-ink/30 underline-offset-4 hover:decoration-ink"
            >
              Clear filters
            </button>
          ) : null}
        </div>

        <h2 className="sr-only">Products</h2>
        {results.length > 0 ? (
          <ProductGrid products={results} layout={showCategoryFilter ? "sidebar" : "full"} />
        ) : (
          <div className="rounded-media border border-dashed border-line px-6 py-14 text-center">
            <h2 className="text-lg font-semibold text-ink">No products match</h2>
            <p className="mx-auto mt-2 max-w-[42ch] text-[0.9375rem] leading-relaxed text-slate">
              {trimmedQuery
                ? `Nothing found for “${trimmedQuery}”. Check the spelling, try a shorter word, or clear the filters.`
                : "There are no products in this selection yet. Clear the filters to see everything."}
            </p>
            <button
              type="button"
              onClick={() => update({ query: "", category: null })}
              className={`${buttonClasses("primary", "md")} mt-6`}
            >
              Clear filters
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
