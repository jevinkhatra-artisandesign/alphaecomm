import Image from "next/image";
import Link from "next/link";
import { ProductCatalogue } from "@/components/catalogue/ProductCatalogue";
import { Container } from "@/components/ui/Container";
import { PageHeader } from "@/components/ui/PageHeader";
import { categories, getCategoryHref } from "@/data/categories";
import { getProductsByCategory } from "@/data/products";
import { getCategoryTone } from "@/lib/category-tones";
import type { Category } from "@/types/product";

const pillClasses =
  "inline-flex h-11 items-center gap-2 rounded-control border border-line px-4 text-sm font-medium text-ink hover:border-ink/40";

export function CategoryPage({ category }: { category: Category }): React.JSX.Element {
  const categoryProducts = getProductsByCategory(category.slug);
  const otherCategories = categories.filter((item) => item.slug !== category.slug);
  const tone = getCategoryTone(category.slug);
  const otherHeadingId = `other-categories-${category.slug}`;

  return (
    <>
      {/* Header band in the category's own colour */}
      <div className={tone.surface}>
        <Container className="py-10 md:py-14">
          <PageHeader
            breadcrumbs={[
              { label: "Home", href: "/" },
              { label: "Shop All", href: "/shop" },
              { label: category.name },
            ]}
            title={category.name}
            description={category.description}
            aside={
              <div className="relative aspect-[16/9] overflow-hidden rounded-media bg-paper">
                <Image
                  src={category.image.src}
                  alt={category.image.alt}
                  fill
                  preload
                  sizes="(min-width: 768px) 24rem, 100vw"
                  className="object-cover"
                />
              </div>
            }
          />
        </Container>
      </div>

      <Container className="py-10 md:py-12">
        <ProductCatalogue
          products={categoryProducts}
          categories={categories}
          lockedCategory={category.slug}
        />

        <nav aria-labelledby={otherHeadingId} className="mt-20 border-t border-line pt-10">
          <h2 id={otherHeadingId} className="text-base font-semibold text-ink">
            Other categories
          </h2>
          <ul className="mt-4 flex flex-wrap gap-2">
            {otherCategories.map((item) => (
              <li key={item.id}>
                <Link href={getCategoryHref(item.slug)} className={pillClasses}>
                  <span
                    aria-hidden="true"
                    className={`size-2 rounded-full ${getCategoryTone(item.slug).dot}`}
                  />
                  {item.name}
                </Link>
              </li>
            ))}
            <li>
              <Link href="/shop" className={pillClasses}>
                All products
              </Link>
            </li>
          </ul>
        </nav>
      </Container>
    </>
  );
}
