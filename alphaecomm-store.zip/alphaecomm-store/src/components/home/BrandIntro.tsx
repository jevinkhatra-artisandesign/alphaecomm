import { Container } from "@/components/ui/Container";
import { Eyebrow } from "@/components/ui/Eyebrow";

const steps = [
  {
    title: "Choose your products",
    body: "Browse the catalogue and note what you’d like.",
  },
  {
    title: "Message us on WhatsApp",
    body: "Send your list using the Enquire button. We’ll confirm availability and the total.",
  },
  {
    title: "Pay by UPI",
    body: "We share a UPI QR code in the chat. Once payment is confirmed, we prepare your order.",
  },
];

export function BrandIntro(): React.JSX.Element {
  return (
    <section id="about" aria-labelledby="about-title" className="border-t border-line py-16 md:py-24">
      <Container className="grid gap-12 md:grid-cols-2 md:gap-16">
        <div>
          <Eyebrow>Who we are</Eyebrow>
          <h2 id="about-title" className="text-title font-semibold text-ink">
            About Alphaecomm Enterprise
          </h2>
          <p className="mt-5 max-w-[52ch] text-base leading-relaxed text-slate">
            We’re a multi-category store selling kitchenware, home organisation products, toys and
            everyday essentials. Ordering is personal and simple: you talk to us directly, and we
            help you with every order.
          </p>
        </div>

        <div>
          <h3 className="text-base font-semibold text-ink">How ordering works</h3>
          <ol className="mt-5 space-y-6">
            {steps.map((step, index) => (
              <li key={step.title} className="grid grid-cols-[2rem_1fr] gap-3">
                <span
                  aria-hidden="true"
                  className="flex size-7 items-center justify-center rounded-full bg-sage text-xs font-semibold text-action"
                >
                  {index + 1}
                </span>
                <div>
                  <p className="font-medium text-ink">{step.title}</p>
                  <p className="mt-1 text-[0.9375rem] leading-relaxed text-slate">{step.body}</p>
                </div>
              </li>
            ))}
          </ol>
        </div>
      </Container>
    </section>
  );
}
