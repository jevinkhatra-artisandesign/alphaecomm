import { ProductGrid } from "@/components/products/ProductGrid";
import { Container } from "@/components/ui/Container";
import { SectionHeader } from "@/components/ui/SectionHeader";
import type { Product } from "@/types/product";

interface ProductSectionProps {
  id: string;
  title: string;
  description?: string;
  eyebrow?: string;
  products: Product[];
  tone?: "paper" | "linen";
}

/** Titled product grid with a link to the full catalogue. Used for featured and "more" rows. */
export function FeaturedProducts({
  id,
  title,
  description,
  eyebrow,
  products,
  tone = "paper",
}: ProductSectionProps): React.JSX.Element {
  return (
    <section
      aria-labelledby={`${id}-title`}
      className={`py-16 md:py-24 ${tone === "linen" ? "bg-linen" : "bg-paper"}`}
    >
      <Container>
        <SectionHeader
          id={`${id}-title`}
          title={title}
          description={description}
          eyebrow={eyebrow}
          action={{ label: "View all products", href: "/shop" }}
        />
        <ProductGrid products={products} />
      </Container>
    </section>
  );
}
