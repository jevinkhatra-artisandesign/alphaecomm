import { BrandIntro } from "@/components/home/BrandIntro";
import { CategoryGrid } from "@/components/home/CategoryGrid";
import { FeaturedProducts } from "@/components/home/FeaturedProducts";
import { Hero } from "@/components/home/Hero";
import { WhatsAppContact } from "@/components/home/WhatsAppContact";
import { getFeaturedProducts, getMoreProducts } from "@/data/products";

export function HomePage(): React.JSX.Element {
  return (
    <>
      <Hero />
      <CategoryGrid />
      <FeaturedProducts
        id="featured"
        eyebrow="Picked for you"
        title="Featured products"
        description="A few pieces we’d point you to first."
        products={getFeaturedProducts(4)}
        tone="linen"
      />
      <FeaturedProducts id="more" eyebrow="Keep browsing" title="More to explore" products={getMoreProducts(4)} />
      <BrandIntro />
      <WhatsAppContact />
    </>
  );
}
