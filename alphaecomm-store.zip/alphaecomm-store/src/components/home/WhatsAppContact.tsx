import { Container } from "@/components/ui/Container";
import { WhatsAppLink } from "@/components/ui/WhatsAppLink";
import { getGeneralEnquiryMessage } from "@/lib/whatsapp";

export function WhatsAppContact(): React.JSX.Element {
  return (
    <section aria-labelledby="contact-title" className="bg-action py-16 text-paper md:py-20">
      <Container className="flex flex-col gap-8 md:flex-row md:items-center md:justify-between">
        <div className="max-w-xl">
          <h2 id="contact-title" className="text-title font-semibold">
            Questions before you order?
          </h2>
          <p className="mt-3 text-base leading-relaxed text-paper/85">
            Message us on WhatsApp about a product, availability or an order you’ve placed.
          </p>
        </div>
        <WhatsAppLink
          message={getGeneralEnquiryMessage()}
          ariaLabel="Chat with us on WhatsApp"
          variant="secondary"
          className="self-start border-transparent md:self-auto"
        >
          Chat on WhatsApp
        </WhatsAppLink>
      </Container>
    </section>
  );
}
