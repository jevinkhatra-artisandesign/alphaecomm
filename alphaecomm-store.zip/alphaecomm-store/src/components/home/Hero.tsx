import { getImageProps } from "next/image";
import { ButtonLink } from "@/components/ui/ButtonLink";
import { Container } from "@/components/ui/Container";
import { Eyebrow } from "@/components/ui/Eyebrow";

const BANNER_ALT =
  "Dry fruit slicer, pink lunch box, baby spinner, racing car and other toys on pastel display stands";

/**
 * Hero banner with art direction: phones get the tall banner, tablets and
 * desktops the wide one. The browser downloads only the banner it shows.
 *
 * Layout per screen size:
 * - Phone (<640px):          text on top, tall banner anchored to the bottom.
 * - Tablet/laptop (640–1279): text on top, wide banner below, cropped from its
 *                             empty left side.
 * - Desktop (1280px+):       banner anchored right at its true proportions, text
 *                             on the left. The hero height (clamp 560–720px, 40vw)
 *                             keeps the products right of the text at every width.
 * Banner edges fade into a solid colour sampled from the photo, so there's no
 * visible seam behind the text.
 */
export function Hero(): React.JSX.Element {
  const common = { alt: BANNER_ALT, sizes: "100vw", quality: 80 };
  const {
    props: { srcSet: wideSrcSet },
  } = getImageProps({ ...common, src: "/images/hero/hero-wide.webp", width: 1758, height: 895 });
  const {
    props: { srcSet: tallSrcSet, ...imgProps },
  } = getImageProps({ ...common, src: "/images/hero/hero-tall.webp", width: 940, height: 1672 });

  return (
    <section
      aria-labelledby="hero-title"
      className="relative overflow-hidden bg-hero-tall sm:bg-hero-wide"
    >
      <picture>
        <source media="(min-width: 640px)" srcSet={wideSrcSet} />
        <img
          {...imgProps}
          srcSet={tallSrcSet}
          alt={BANNER_ALT}
          loading="eager"
          fetchPriority="high"
          className="absolute inset-x-0 bottom-0 h-auto w-full [mask-image:linear-gradient(to_bottom,transparent_0%,rgb(0_0_0/0.35)_24%,black_46%)] sm:h-[61vw] sm:object-cover lg:h-[41vw] sm:object-[right_bottom] sm:[mask-image:linear-gradient(to_bottom,transparent_0%,black_18%)] xl:inset-x-auto xl:top-0 xl:right-0 xl:h-full xl:w-auto xl:max-w-none xl:[mask-image:linear-gradient(to_right,transparent_0%,black_22%)]"
        />
      </picture>

      {/* Desktop only: soft scrim behind the text for steady contrast over the photo */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-y-0 left-0 hidden w-[55%] bg-linear-to-r from-hero-wide via-hero-wide/60 to-transparent xl:block"
      />

      <Container className="relative pb-[100vw] pt-10 sm:pb-[58vw] sm:pt-14 lg:pb-[39vw] xl:flex xl:min-h-[clamp(560px,40vw,720px)] xl:items-center xl:pb-12 xl:pt-12">
        <div className="max-w-[34rem] xl:max-w-[26rem] 2xl:max-w-[32rem]">
          <Eyebrow>Kitchen · Home · Toys · Essentials</Eyebrow>
          <h1
            id="hero-title"
            className="max-w-[14ch] text-display font-semibold text-ink lg:text-[clamp(2.75rem,1.2rem+2.4vw,4rem)]"
          >
            Useful things for the kitchen, home and every day.
          </h1>
          <p className="mt-5 max-w-[46ch] text-lg leading-relaxed text-ink/80 xl:max-w-[36ch]">
            Browse kitchenware, home organisation, toys and daily essentials in one place, then
            order directly with us on WhatsApp.
          </p>
          <div className="mt-7 flex flex-wrap gap-3">
            <ButtonLink href="/shop">Shop all</ButtonLink>
            <ButtonLink href="/#categories" variant="secondary">
              Explore categories
            </ButtonLink>
          </div>
        </div>
      </Container>
    </section>
  );
}
