import Image from "next/image";
import Link from "next/link";
import { Container } from "@/components/ui/Container";
import { SectionHeader } from "@/components/ui/SectionHeader";
import { categories, getCategoryHref } from "@/data/categories";
import { products } from "@/data/products";
import { getCategoryTone } from "@/lib/category-tones";

function countProducts(categorySlug: string): number {
  return products.filter((product) => product.categorySlug === categorySlug).length;
}

/** Each category is a coloured card, so colour remains once real photos replace the placeholders. */
export function CategoryGrid(): React.JSX.Element {
  return (
    <section id="categories" aria-labelledby="categories-title" className="py-16 md:py-24">
      <Container>
        <SectionHeader
          id="categories-title"
          eyebrow="Departments"
          title="Shop by category"
          description="Four departments, each kept small and considered."
        />
        <ul className="grid gap-4 sm:grid-cols-2 sm:gap-6">
          {categories.map((category) => {
            const count = countProducts(category.slug);
            const tone = getCategoryTone(category.slug);
            return (
              <li key={category.id}>
                <Link
                  href={getCategoryHref(category.slug)}
                  className={`group block rounded-[10px] p-3 transition-[filter] hover:brightness-[0.97] sm:p-4 ${tone.surface}`}
                >
                  <div className="relative aspect-[4/3] overflow-hidden rounded-media lg:aspect-[16/9]">
                    <Image
                      src={category.image.src}
                      alt={category.image.alt}
                      fill
                      sizes="(min-width: 640px) 50vw, 100vw"
                      className="object-cover"
                    />
                  </div>
                  <div className="px-1 pb-1 pt-4">
                    <div className="flex items-baseline justify-between gap-4">
                      <h3 className="text-xl font-semibold tracking-[-0.01em] text-ink group-hover:underline group-hover:underline-offset-4 md:text-2xl">
                        {category.name}
                      </h3>
                      <span className="shrink-0 text-sm text-ink/70">
                        {count === 0 ? "Coming soon" : `${count} ${count === 1 ? "product" : "products"}`}
                      </span>
                    </div>
                    <p className="mt-1.5 text-[0.9375rem] text-ink/70">{category.description}</p>
                  </div>
                </Link>
              </li>
            );
          })}
        </ul>
      </Container>
    </section>
  );
}
