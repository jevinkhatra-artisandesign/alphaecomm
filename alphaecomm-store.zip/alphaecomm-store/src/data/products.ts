import { assertCatalogueIntegrity } from "@/data/validate";
import type { Product } from "@/types/product";

/**
 * Canonical product list — the single source of truth for the catalogue.
 *
 * Descriptions only state what is visible in the product photos or printed
 * on the packaging. Add materials, sizes and age guidance in `specifications`
 * once confirmed with the supplier.
 *
 * PRICES match the Alphaecomm Enterprise Meesho listings. `compareAtPrice` is
 * the MRP shown crossed out there. The Baby Spinner's price is still to be
 * added; until then it shows "Price on request".
 */

const img = (slug: string, n: number, alt: string) => ({
  src: `/images/products/${slug}/${String(n).padStart(2, "0")}.webp`,
  alt,
});

export const products: Product[] = [
  // ───────────── Kitchen & Dining ─────────────
  {
    id: "ae-kd-001",
    slug: "dry-fruit-slicer",
    name: "Dry Fruit Slicer",
    sku: "AE-KD-001",
    price: 154,
    categorySlug: "kitchen-dining",
    shortDescription: "Slices almonds and other dry fruits into thin flakes.",
    description:
      "A hand-held dry fruit slicer with a stainless steel cross blade. Load the dry fruits, twist and press, and the slices collect in the clear container below.\n\nIncludes the slicer body, the blade unit, a pusher and the clear collection container, packed in a retail box.",
    images: [
      img("dry-fruit-slicer", 1, "Green dry fruit slicer shown assembled, with its blade unit, pusher and retail box"),
      img("dry-fruit-slicer", 2, "Hands pressing the dry fruit slicer, with sliced almonds collected in the clear container"),
      img("dry-fruit-slicer", 3, "Dry fruit slicer on a kitchen counter next to bowls of almonds, cashews and pistachios"),
      img("dry-fruit-slicer", 4, "Dry fruit slicer on a dining table with sliced almonds in the container"),
    ],
    inStock: true,
    featured: true,
    tags: ["slicer", "dry fruits", "almonds", "kitchen tools"],
  },

  // ───────────── Everyday Essentials ─────────────
  {
    id: "ae-ee-001",
    slug: "stainless-steel-lunch-box-pink",
    name: "Stainless Steel Lunch Box – Pink",
    sku: "AE-EE-001",
    price: 401,
    categorySlug: "everyday-essentials",
    shortDescription: "Three-compartment lunch box with a clip-lock lid.",
    description:
      "A pink lunch box with a stainless steel inner tray divided into three compartments, including a round bowl with its own lid. A clear lid closes over the top with clips on every side.",
    images: [
      img("stainless-steel-lunch-box-pink", 1, "Pink lunch box with a clear clip-lock lid over a three-compartment steel tray"),
      img("stainless-steel-lunch-box-pink", 2, "Lunch box open, filled with fruit, pasta and nuggets in its three compartments"),
      img("stainless-steel-lunch-box-pink", 3, "Pink lunch box on a marble counter beside fresh vegetables"),
    ],
    inStock: true,
    featured: true,
    tags: ["lunch box", "tiffin", "stainless steel", "school", "office"],
  },

  // ───────────── Toys & Kids ─────────────
  {
    id: "ae-tk-001",
    slug: "projector-flashlight-toy",
    name: "Projector Flashlight Toy",
    sku: "AE-TK-001",
    price: 204,
    compareAtPrice: 238,
    categorySlug: "toys-kids",
    shortDescription: "A flashlight that projects pictures from 3 picture discs.",
    description:
      "A flashlight that doubles as a picture projector. Insert a picture disc, slide the switch to turn it on, and rotate the head to change the picture on the wall.\n\nComes with 3 interchangeable picture discs.",
    images: [
      // Lifestyle photo first: the text-heavy infographics read poorly at card size.
      img("projector-flashlight-toy", 2, "Child lying on a rug, projecting a lion picture onto the wall with the flashlight"),
      img("projector-flashlight-toy", 1, "Green projector flashlight with three picture discs and sample projected pictures"),
      img("projector-flashlight-toy", 3, "Hand holding the flashlight showing the slide switch and rotating head"),
      img("projector-flashlight-toy", 4, "Four steps: insert the disc, rotate to change picture, switch on, project"),
    ],
    inStock: true,
    featured: true,
    tags: ["projector", "flashlight", "torch", "kids", "toys"],
  },
  {
    id: "ae-tk-002",
    slug: "racing-car-toy-red",
    name: "Formula-Style Racing Car Toy – Red",
    sku: "AE-TK-002",
    price: 269,
    categorySlug: "toys-kids",
    shortDescription: "A red formula-style racing car with rubber-look tyres.",
    description:
      "A red, single-seater formula-style racing car toy with a front and rear wing and racing decals.",
    images: [
      img("racing-car-toy-red", 1, "Red formula-style racing car toy on a white background"),
      img("racing-car-toy-red", 2, "Smiling child playing with the red racing car on a wooden floor"),
      img("racing-car-toy-red", 3, "Red racing car toy on a miniature race track"),
    ],
    inStock: true,
    featured: true,
    tags: ["car", "racing car", "toy car", "kids", "toys"],
  },
  {
    id: "ae-tk-003",
    slug: "racing-car-toy-black-orange",
    name: "Formula-Style Racing Car Toy – Black & Orange",
    sku: "AE-TK-003",
    price: 289,
    categorySlug: "toys-kids",
    shortDescription: "A black and orange formula-style racing car, in a display box.",
    description:
      "A black and orange single-seater formula-style racing car toy with blue accents and racing decals. Supplied in a window display box.",
    images: [
      img("racing-car-toy-black-orange", 1, "Black and orange racing car toy in front of its window display box"),
      img("racing-car-toy-black-orange", 2, "The racing car beside its box on a wooden table"),
      img("racing-car-toy-black-orange", 3, "Front view of the black and orange racing car"),
      img("racing-car-toy-black-orange", 4, "Side view of the black and orange racing car"),
      img("racing-car-toy-black-orange", 5, "Rear view showing the racing car's rear wing"),
      img("racing-car-toy-black-orange", 6, "Racing car toy in an illustrated race scene (track and loop not included)"),
    ],
    specifications: [{ label: "Age (printed on box)", value: "3+" }],
    inStock: true,
    featured: false,
    tags: ["car", "racing car", "toy car", "kids", "toys"],
  },
  {
    id: "ae-tk-004",
    slug: "baby-spinner-toy-set-of-3",
    name: "Baby Spinner Toy – Set of 3",
    sku: "AE-TK-004",
    categorySlug: "toys-kids",
    shortDescription: "Three suction-cup spinner toys with animal characters.",
    description:
      "A set of three colourful spinner toys, each with an animal character in the centre and a suction-cup base that holds it to smooth surfaces. Spin them with a finger.\n\nPacked in a retail box.",
    images: [
      img("baby-spinner-toy-set-of-3", 1, "Three spinner toys in blue, pink and yellow in front of the Baby Spinner box"),
      img("baby-spinner-toy-set-of-3", 2, "Smiling child spinning the blue spinner on a table"),
      img("baby-spinner-toy-set-of-3", 3, "Blue spinner with a yellow animal character held in a hand"),
      img("baby-spinner-toy-set-of-3", 4, "The three spinners and box on a dark stone surface"),
    ],
    specifications: [{ label: "Pieces (printed on box)", value: "3" }],
    inStock: true,
    featured: false,
    tags: ["spinner", "suction toy", "bath toy", "baby", "toys"],
  },
  {
    id: "ae-tk-005",
    slug: "beach-sand-bucket-set",
    name: "Beach Sand Bucket Set",
    sku: "AE-TK-005",
    price: 247,
    compareAtPrice: 290,
    categorySlug: "toys-kids",
    shortDescription: "A bucket with sand moulds, shovel and rake, in a mesh bag.",
    description:
      "A sand play set with a bucket, sand moulds, a shovel and a rake, packed in a mesh bag with a drawstring for carrying and storage.",
    images: [
      img("beach-sand-bucket-set", 1, "Blue sand bucket with moulds, shovel and rake in a white mesh bag"),
      img("beach-sand-bucket-set", 2, "Child on a beach scooping sand into the bucket with the yellow shovel"),
      img("beach-sand-bucket-set", 3, "Close-ups of the set: bucket, shovel, sand moulds and mesh bag"),
    ],
    inStock: true,
    featured: false,
    tags: ["sand", "beach", "bucket", "outdoor", "toys"],
  },
];

// Fails the build early if slugs/SKUs repeat or a category reference is wrong.
assertCatalogueIntegrity(products);

export function getFeaturedProducts(limit?: number): Product[] {
  const featured = products.filter((product) => product.featured);
  return typeof limit === "number" ? featured.slice(0, limit) : featured;
}

export function getMoreProducts(limit?: number): Product[] {
  const rest = products.filter((product) => !product.featured);
  return typeof limit === "number" ? rest.slice(0, limit) : rest;
}

export function getProductBySlug(slug: string): Product | undefined {
  return products.find((product) => product.slug === slug);
}

export function getProductsByCategory(categorySlug: string): Product[] {
  return products.filter((product) => product.categorySlug === categorySlug);
}

/**
 * Up to `limit` in-stock products from the same category, topped up with
 * featured in-stock products when the category is too small.
 */
export function getRelatedProducts(product: Product, limit = 4): Product[] {
  const isCandidate = (candidate: Product): boolean =>
    candidate.id !== product.id && candidate.inStock;

  const related = products.filter(
    (candidate) => isCandidate(candidate) && candidate.categorySlug === product.categorySlug,
  );
  if (related.length < limit) {
    const fill = products.filter(
      (candidate) => isCandidate(candidate) && candidate.featured && !related.includes(candidate),
    );
    related.push(...fill);
  }
  return related.slice(0, limit);
}

export function getProductHref(slug: string): string {
  return `/product/${slug}`;
}
