import { categories } from "@/data/categories";
import type { Product } from "@/types/product";

/**
 * Catches data mistakes when the site builds or starts, instead of
 * showing broken links to customers. Throws with a readable message.
 */
export function assertCatalogueIntegrity(products: Product[]): void {
  const problems: string[] = [];
  const categorySlugs = new Set(categories.map((category) => category.slug));
  const seen = { id: new Set<string>(), slug: new Set<string>(), sku: new Set<string>() };

  for (const product of products) {
    for (const key of ["id", "slug", "sku"] as const) {
      const value = product[key].trim().toLowerCase();
      if (!value) problems.push(`"${product.name}" has an empty ${key}.`);
      else if (seen[key].has(value)) problems.push(`Duplicate ${key} "${product[key]}".`);
      seen[key].add(value);
    }
    if (!categorySlugs.has(product.categorySlug)) {
      problems.push(`"${product.name}" uses unknown category "${product.categorySlug}".`);
    }
    if (product.price !== undefined && (!Number.isFinite(product.price) || product.price < 0)) {
      problems.push(`"${product.name}" has an invalid price.`);
    }
  }

  if (problems.length > 0) {
    throw new Error(`Product data needs fixing:\n- ${problems.join("\n- ")}`);
  }
}
