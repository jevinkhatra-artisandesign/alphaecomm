import type { Category } from "@/types/product";

/**
 * Canonical category list. To replace an image, drop a photo into
 * public/images/categories/ and update `image.src` below.
 */
export const categories: Category[] = [
  {
    id: "cat-kitchen-dining",
    slug: "kitchen-dining",
    name: "Kitchen & Dining",
    description: "Cookware, storage and serving pieces for daily cooking.",
    image: {
      src: "/images/categories/kitchen-dining.webp",
      alt: "Dry fruit slicer on a kitchen counter with bowls of almonds and cashews",
    },
  },
  {
    id: "cat-home-living",
    slug: "home-living",
    name: "Home & Living",
    description: "Organisers and storage that keep rooms in order.",
    image: {
      src: "/images/categories/home-living.svg",
      alt: "Illustration of a woven basket and drawer organiser",
    },
  },
  {
    id: "cat-toys-kids",
    slug: "toys-kids",
    name: "Toys & Kids",
    description: "Toys and play pieces for little ones.",
    image: {
      src: "/images/categories/toys-kids.webp",
      alt: "Child playing with a sand bucket set on the beach",
    },
  },
  {
    id: "cat-everyday-essentials",
    slug: "everyday-essentials",
    name: "Everyday Essentials",
    description: "Practical things you reach for every day.",
    image: {
      src: "/images/categories/everyday-essentials.webp",
      alt: "Pink stainless steel lunch box on a marble counter",
    },
  },
];

export function getCategoryBySlug(slug: string): Category | undefined {
  return categories.find((category) => category.slug === slug);
}

export function getCategoryHref(slug: string): string {
  return `/category/${slug}`;
}
