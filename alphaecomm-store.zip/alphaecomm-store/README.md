# Alphaecomm Enterprise — Storefront

Product catalogue website for Alphaecomm Enterprise. Customers browse products and order on WhatsApp; payment is by UPI QR code shared in the chat.

## Pages

| Route | What it is |
| --- | --- |
| `/` | Homepage |
| `/shop` | All products with live search, category filter and sort. State is kept in the URL, e.g. `/shop?q=jar&category=kitchen-dining&sort=price-asc`, so filtered views can be shared. |
| `/category/[slug]` | One category, with search and sort |
| `/product/[slug]` | Product detail: gallery, SKU, price, stock, WhatsApp ordering, related products |

All category and product pages are prerendered as static HTML. Unknown slugs return a real HTTP 404 (checked in `src/proxy.ts`). Policy pages are not built yet and show the not-found page.

## Run it on your computer

You need **Node.js 20.9 or newer** (check with `node -v`). Download it from nodejs.org if needed.

```bash
cd alphaecomm-store
npm install                 # first time only — downloads dependencies
cp .env.example .env.local  # on Windows: copy .env.example .env.local
npm run dev                 # starts the site at http://localhost:3000
```

| Command | What it does |
| --- | --- |
| `npm run dev` | Development server with live reload |
| `npm run lint` | Checks code for problems |
| `npm run typecheck` | Checks TypeScript types |
| `npm run build` | Production build (run before deploying) |
| `npm run start` | Serves the production build |

## Settings (`.env.local`)

| Variable | Example | Purpose |
| --- | --- | --- |
| `NEXT_PUBLIC_WHATSAPP_NUMBER` | `919876543210` | Country code + number, digits only. While empty, WhatsApp buttons are shown disabled. |
| `NEXT_PUBLIC_SITE_URL` | `https://www.example.com` | Live site address, used for SEO and link previews. |

Restart `npm run dev` after changing these.

## Where things live

```
src/
  app/            layout.tsx (header/footer/SEO), page.tsx (homepage), not-found.tsx, globals.css (design tokens)
  components/
    layout/       Header, MobileNav, SearchForm, BrandMark, Footer, DevNotice
    home/         Hero, CategoryGrid, FeaturedProducts, BrandIntro, WhatsAppContact, HomePage
    products/     ProductCard, ProductGrid, ProductPrice, StockStatus, WhatsAppOrderButton
    ui/           Container, ButtonLink, WhatsAppLink, SectionHeader, button-styles
  components/catalogue/  ProductCatalogue (search/filter/sort), ShopPage, CategoryPage
  data/           products.ts and categories.ts — the only place product data lives; validate.ts checks it
  lib/            whatsapp.ts (messages), catalogue.ts (search/sort logic), format-price.ts, site.ts
  proxy.ts        returns 404 for unknown product/category URLs
  types/          product.ts — Product and Category models
  fonts/          Instrument Sans (bundled, SIL Open Font License)
public/images/    products/, categories/, brand/
```

## Common edits

- **Colours, fonts, corner radius** → `src/app/globals.css`, inside `@theme`.
- **Add prices** → `src/data/products.ts`: add `price: 299,` (whole rupees) to a product. Without it the site shows "Price on request" and the WhatsApp message asks for the price.
- **Product photos** → `public/images/products/<slug>/01.webp`, `02.webp`, … (square, 1200px WebP; the first is the card image).
- **Add or replace products** → `src/data/products.ts`. Each product needs a unique `slug` and `sku`, and a `categorySlug` that exists in `categories.ts` — the build stops with a clear message if not. Put photos in `public/images/products/<slug>/` as square images.
- **Category images** → `public/images/categories/` (4:3 landscape), then update `src/data/categories.ts`.
- **Real logo** → place it at `public/images/brand/logo.svg` and update `src/components/layout/BrandMark.tsx`.
- **Compare-at price** → set `compareAtPrice` only when the business supplies it. Shown struck through, and only if higher than `price`.

## WhatsApp behaviour

The business number lives in `.env.local` as `NEXT_PUBLIC_WHATSAPP_NUMBER=919265113493` (country code + number, digits only). When deploying, add the same variable in your hosting provider's environment settings, together with `NEXT_PUBLIC_SITE_URL` (your live address) so product links in WhatsApp messages point to the live site.

- **Floating button:** a WhatsApp button stays in the bottom-right corner on every page (round icon on phones, "Chat on WhatsApp" on larger screens) for general enquiries.

- **In stock:** "Order on WhatsApp" opens a chat pre-filled with the product name, SKU, price, product link, and a request to confirm availability and shipping charges. It does not place an order.
- **Out of stock:** the button becomes "Ask about availability" and the message says the product is shown as out of stock.
- **No number configured:** buttons are shown disabled; no broken links are generated.
- Product links in messages use `NEXT_PUBLIC_SITE_URL`. Until it's set they point to `http://localhost:3000`.

## Good to know (Next.js 16)

Next.js keeps up to 3 recently visited pages mounted but hidden, so going Back restores filters and scroll instantly. For that reason, components that can appear on several pages generate unique ids with React's `useId()` instead of fixed ids.
